# VAE Standalone

该目录是从 Vista 中提炼出的独立 VAE 运行包，仅包含：
- VAE 配置：`config/vae_only.yaml`
- VAE 权重：`weights/vae_only.safetensors`（只含 `first_stage_model.*` 参数）
- 最小代码依赖：`vwm/` 子集
- 入口脚本：`vae_reconstruct.py`

## 1. 安装依赖

```bash
pip install -r requirements.txt
```

## 2. 单图（batch=1）

```bash
python vae_reconstruct.py \
  --image_path ../image_folder/image1.jpg \
  --batch_frames 1 \
  --no_crop --height 384 --width 1152 \
  --output_dir outputs_batch1
```

## 3. 多图按顺序组成 batch

```bash
python vae_reconstruct.py \
  --image_paths ../image_folder/image.png ../image_folder/image1.jpg \
  --no_crop --height 384 --width 1152 \
  --output_dir outputs_2imgs
```

上面命令中：
- 第一帧是 `image.png`
- 第二帧是 `image1.jpg`

## 4. 说明

- 该目录不依赖上层 `sample.py` / `sample_utils.py`。
- 权重只保留 VAE 参数（372 个键）。
- 高宽仍需满足 64 的倍数约束。
