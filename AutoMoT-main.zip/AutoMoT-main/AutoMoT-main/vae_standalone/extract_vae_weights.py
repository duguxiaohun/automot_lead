"""extract_vae_weights.py

从完整 Vista 模型权重中提取 VAE（first_stage_model）部分，
保存为可独立使用的 safetensors 文件。

默认输入：../ckpts/vista.safetensors
默认输出：weights/vae_only.safetensors
"""

import argparse
import os

from safetensors.torch import load_file, save_file


def extract_vae_weights(input_path: str, output_path: str):
    print(f"加载完整权重: {input_path}")
    sd = load_file(input_path)

    prefix = "first_stage_model."
    vae_sd = {k[len(prefix):]: v for k, v in sd.items() if k.startswith(prefix)}

    if not vae_sd:
        raise ValueError(f"在 {input_path} 中未找到 first_stage_model.* 键，请确认权重路径正确。")

    print(f"提取到 VAE 参数共 {len(vae_sd)} 个键")
    print(f"原始总键数: {len(sd)}")

    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    save_file(vae_sd, output_path)
    print(f"已保存到: {output_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="从完整 Vista 权重中提取 VAE 参数")
    parser.add_argument(
        "--input",
        type=str,
        default=os.path.join(os.path.dirname(__file__), "../ckpts/vista.safetensors"),
        help="完整模型权重路径（默认: ../ckpts/vista.safetensors）",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=os.path.join(os.path.dirname(__file__), "weights/vae_only.safetensors"),
        help="输出 VAE 权重路径（默认: weights/vae_only.safetensors）",
    )
    args = parser.parse_args()

    extract_vae_weights(args.input, args.output)
