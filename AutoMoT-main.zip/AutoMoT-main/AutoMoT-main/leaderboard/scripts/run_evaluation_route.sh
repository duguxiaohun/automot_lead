#!/bin/bash
# ============================================================
# Bench2Drive Route-by-Route Evaluation Script
# Runs evaluation for all 220 routes one by one, skipping already completed ones.
# 中文说明：
# 1) 逐条路线执行评测，已产出结果的路线自动跳过，支持断点续跑。
# 2) 自动探测关键路径（项目根目录、CARLA_ROOT）并可通过环境变量覆盖默认输出目录。
# 3) 默认复用同一 CARLA 端口与 TM 端口，按 route_id 串行评测。
# 4) 支持 SINGLE_TEST=1 的烟雾测试模式，仅跑一条后立即退出。
# ============================================================

# 禁用 core dump，避免评测异常时在工作目录生成 core.*。
ulimit -S -c 0 2>/dev/null || true

# Auto-detect paths from script location
# 通过脚本自身位置反推目录，避免依赖调用时的当前工作目录（cwd）。
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LEADERBOARD_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
PROJECT_ROOT="$(cd "${LEADERBOARD_DIR}/.." && pwd)"

# Auto-detect CARLA_ROOT if not set
# 若外部未设置 CARLA_ROOT，则按常见目录自动查找：
# 1) 项目同级目录 carla
# 2) 用户家目录 ~/carla
# 两处都未命中则报错退出，避免后续评测在错误环境下运行。
if [ -z "${CARLA_ROOT}" ]; then
    if [ -d "$(dirname "${PROJECT_ROOT}")/carla" ]; then
        export CARLA_ROOT="$(dirname "${PROJECT_ROOT}")/carla"
    elif [ -d "${HOME}/carla" ]; then
        export CARLA_ROOT="${HOME}/carla"
    else
        echo "ERROR: CARLA_ROOT is not set and could not be auto-detected."
        echo "Please export CARLA_ROOT=/path/to/carla"
        exit 1
    fi
    echo "Auto-detected CARLA_ROOT=${CARLA_ROOT}"
fi

# BASE_PORT 可由外部覆盖；默认从 5000 起。
# 注意：在 AUTO_PORT_BY_GPU_SLOT=1 时，会在后续根据 GPU_RANK 自动重算。
BASE_PORT="${BASE_PORT:-5000}"
BASE_TM_PORT=$((BASE_PORT + 8000))
IS_BENCH2DRIVE=True
BASE_ROUTES=${LEADERBOARD_DIR}/data/bench2drive220
TEAM_AGENT=leaderboard/team_code/mot_b2d_agent.py
TEAM_CONFIG=${PROJECT_ROOT}/Automot/checkpoints+automot_eval
# Persist evaluation artifacts in a dedicated outputs directory by default.
# You can override these paths with env vars when launching the script.
# EVAL_OUTPUT_DIR: 逐路线评测结果汇总目录（最终保存为 eval_<route_id>.json）
# BASE_CHECKPOINT_ENDPOINT: run_evaluation.sh 运行时写出的临时/中间评测文件前缀
# SAVE_PATH: 代理运行时的附加输出目录（如可视化、日志、缓存等，取决于下游实现）
EVAL_OUTPUT_DIR="${EVAL_OUTPUT_DIR:-${PROJECT_ROOT}/outputs/leaderboard/v_2json_open}"
BASE_CHECKPOINT_ENDPOINT="${BASE_CHECKPOINT_ENDPOINT:-${EVAL_OUTPUT_DIR}/eval_latest}"
SAVE_PATH="${SAVE_PATH:-${PROJECT_ROOT}/outputs/leaderboard/eval_v1/}"
PLANNER_TYPE=only_traj
GPU_RANK="${GPU_RANK:-}"

# Pick the same GPU for CARLA and evaluation.
# Priority: explicit GPU_RANK > auto-detect least-used GPU > fallback to 0.
# 说明：
# - 统一 CARLA 与评测进程使用同一 GPU，便于资源管理与复现实验。
# - 自动模式下根据显存占用最小策略选卡，降低与其他任务冲突概率。
if [ -n "${GPU_RANK}" ]; then
    echo "Using user-specified GPU_RANK=${GPU_RANK}"
elif command -v nvidia-smi >/dev/null 2>&1; then
    GPU_RANK=$(nvidia-smi --query-gpu=index,memory.used --format=csv,noheader,nounits | sort -t ',' -k2 -n | awk -F ',' 'NR==1 {gsub(/ /, "", $1); print $1}')
    if [ -z "${GPU_RANK}" ]; then
        GPU_RANK=0
    fi
    echo "Auto-selected least-memory GPU_RANK=${GPU_RANK}"
else
    GPU_RANK=0
    echo "nvidia-smi not found, fallback GPU_RANK=${GPU_RANK}"
fi
# Auto-selected least-memory GPU_RANK=0

# 多卡并行端口分配策略（默认开启）：
# - 目标：0~7 卡并行时，每个评测进程有稳定且互不重叠的端口槽位。
# - 规则：BASE_PORT = PORT_BASE_START + GPU_RANK * PORT_STRIDE。
# - 默认槽位：
#   GPU0->5000, GPU1->5020, GPU2->5040, ... GPU7->5140
# - 每个槽位跨度 20，远大于 CARLA 启动时预留的连续端口块，降低并发抢占风险。
AUTO_PORT_BY_GPU_SLOT="${AUTO_PORT_BY_GPU_SLOT:-1}"
PORT_BASE_START="${PORT_BASE_START:-5000}"
PORT_STRIDE="${PORT_STRIDE:-20}"
if [ "${AUTO_PORT_BY_GPU_SLOT}" = "1" ]; then
    if [[ "${GPU_RANK}" =~ ^[0-9]+$ ]] && [[ "${PORT_BASE_START}" =~ ^[0-9]+$ ]] && [[ "${PORT_STRIDE}" =~ ^[0-9]+$ ]]; then
        BASE_PORT=$((PORT_BASE_START + GPU_RANK * PORT_STRIDE))
        BASE_TM_PORT=$((BASE_PORT + 8000))
        echo "Auto port slot by GPU enabled: GPU_RANK=${GPU_RANK}, BASE_PORT=${BASE_PORT}, TM_PORT=${BASE_TM_PORT}, STRIDE=${PORT_STRIDE}"
    else
        echo "WARNING: AUTO_PORT_BY_GPU_SLOT=1 but GPU_RANK/PORT_BASE_START/PORT_STRIDE is not integer, keep BASE_PORT=${BASE_PORT}"
    fi
fi

# bash /home/cruser1/lda/AutoMoT/start_carla.sh -p ${BASE_PORT} -g ${GPU_RANK}

# 预创建输出目录，确保后续 cp/写文件不会因目录不存在而失败。
mkdir -p "$EVAL_OUTPUT_DIR"
mkdir -p "$SAVE_PATH"
# export USE_EMA_WEIGHTS=1  # Disabled: EMA weights cause decoding crash (empty answer_ids)
EVAL_JSON_DIR="${PROJECT_ROOT}/eval_json"
SPLIT_FILE_1="${EVAL_JSON_DIR}/b2d_all_routes_split1.json"
SPLIT_FILE_2="${EVAL_JSON_DIR}/b2d_all_routes_split2.json"
MERGED_FILE="${EVAL_JSON_DIR}/b2d_all_routes_merged.json"
TM_SEED="${TM_SEED:-3407}"
# SINGLE_TEST=1: only run one route then stop (smoke test mode).
# SINGLE_TEST=0: run all pending routes.
# 该开关适合做“环境是否可用”的快速检查：
# - 能否正常启动仿真
# - 能否正常进入 run_evaluation.sh
# - 能否成功产出一份 eval json
SINGLE_TEST="${SINGLE_TEST:-0}"

# Check split files exist
# 提前检查输入清单，避免在中途才因文件缺失失败。
if [ ! -f "$SPLIT_FILE_1" ] || [ ! -f "$SPLIT_FILE_2" ]; then
    echo "Error: split files not found:"
    echo "  - $SPLIT_FILE_1"
    echo "  - $SPLIT_FILE_2"
    exit 1
fi

# Merge split files
# 将两份 route id 列表合并为一份统一输入。
# 这里内嵌 Python 仅做数据整理，不依赖项目内部模块，便于跨环境运行。
python3 - "$SPLIT_FILE_1" "$SPLIT_FILE_2" "$MERGED_FILE" << 'PY'
import json, sys
path1, path2, out_path = sys.argv[1:4]

def load_ids(path):
    # 兼容两种格式：
    # 1) {"ids": [...]} 
    # 2) {"routes": [{"id": ...}, ...]}
    with open(path, 'r') as f:
        data = json.load(f)
    return data.get('ids') or [int(r['id']) for r in data.get('routes', [])]

ids = load_ids(path1) + load_ids(path2)
# 历史上可能缺失的 route id 进行兜底补齐，确保评测全集完整。
missing_ids = [1711, 1773]
for mid in missing_ids:
    if mid not in ids:
        ids.append(mid)
with open(out_path, 'w') as f:
    json.dump({'ids': ids}, f, indent=2)
print(f"Merged {len(ids)} route ids -> {out_path}")
# Merged 220 route ids -> /home/cruser1/lda/AutoMoT/eval_json/b2d_all_routes_merged.json

PY

# Extract route IDs
# 再次解析 merged 文件为 shell 数组，供后续 for 循环逐条执行。
mapfile -t ROUTE_IDS < <(python3 - "$MERGED_FILE" << 'PY'
import json, sys
path = sys.argv[1]
with open(path, 'r') as f:
    data = json.load(f)
ids = data.get('ids') or [int(r['id']) for r in data.get('routes', [])]
for i in ids:
    print(i)
PY
)

TOTAL=${#ROUTE_IDS[@]}
CURRENT=0
FAILED_ROUTES=()
COMPLETED_COUNT=0

# Count routes that already have eval results, so we can show pending workload.
# 通过检查 eval_<route_id>.json 是否存在判断“是否已完成”。
# 注意：这里不判断文件内容有效性，仅做存在性判断；如遇损坏文件需手动删除后重跑。
for ROUTE_ID in "${ROUTE_IDS[@]}"; do
    if [ -f "${EVAL_OUTPUT_DIR}/eval_${ROUTE_ID}.json" ]; then
        COMPLETED_COUNT=$((COMPLETED_COUNT + 1))
    fi
done

PENDING_COUNT=$((TOTAL - COMPLETED_COUNT))

echo "=========================================="
echo "Starting evaluation for $TOTAL routes"
echo "Using TrafficManager seed: ${TM_SEED}"
echo "Already completed: ${COMPLETED_COUNT}"
echo "Pending routes   : ${PENDING_COUNT}"
if [ "${SINGLE_TEST}" = "1" ]; then
    echo "Mode             : SINGLE_TEST=1 (will stop after first run)"
else
    echo "Mode             : FULL_RUN"
fi
echo "=========================================="
# ==========================================
# Starting evaluation for 220 routes
# Using TrafficManager seed: 3407
# Already completed: 1
# Pending routes   : 219
# Mode             : SINGLE_TEST=1 (will stop after first run)
# ==========================================

if [ "$TOTAL" -eq 0 ]; then
    echo "No route IDs found. Check split files."
    exit 1
fi

for ROUTE_ID in "${ROUTE_IDS[@]}"; do
    CURRENT=$((CURRENT + 1))
    EXISTING_EVAL="${EVAL_OUTPUT_DIR}/eval_${ROUTE_ID}.json"
    # 已有结果则跳过，实现可重复执行与断点续跑。
    if [ -f "$EXISTING_EVAL" ]; then
        echo ""
        echo "=========================================="
        echo "[$CURRENT/$TOTAL] Skipping route: $ROUTE_ID (already exists)"
        echo "=========================================="
        # ==========================================
        # [1/220] Skipping route: 1711 (already exists)
        # ==========================================
        continue
    fi
    echo ""
    echo "=========================================="
    echo "[$CURRENT/$TOTAL] Running route: $ROUTE_ID"
    echo "=========================================="
    
    PORT=$BASE_PORT
    TM_PORT=$BASE_TM_PORT
    ROUTES="${BASE_ROUTES}.xml"
    CHECKPOINT_ENDPOINT="${BASE_CHECKPOINT_ENDPOINT}.json"
    
    # 参数顺序需与 run_evaluation.sh 的定义严格一致。
    # 末尾附加 route_id 与 tm_seed，实现“固定随机种子 + 指定路线”的单次评测。
    bash "${SCRIPT_DIR}/run_evaluation.sh" \
        $PORT $TM_PORT $IS_BENCH2DRIVE $ROUTES $TEAM_AGENT $TEAM_CONFIG \
        $CHECKPOINT_ENDPOINT $SAVE_PATH $PLANNER_TYPE $GPU_RANK "$ROUTE_ID" "$TM_SEED"
    
    EVAL_EXIT_CODE=$?
    # 记录失败但不中断总流程，保证整批任务最大化完成。
    if [ $EVAL_EXIT_CODE -ne 0 ]; then
        echo "WARNING: run_evaluation.sh failed for route $ROUTE_ID (exit code: $EVAL_EXIT_CODE)"
        FAILED_ROUTES+=("$ROUTE_ID")
    fi
    
    # Copy eval.json to target directory (same as original project)
    # 即使 run_evaluation.sh 返回非 0，只要 checkpoint 文件存在仍尝试归档，便于事后排查。
    if [ -f "$CHECKPOINT_ENDPOINT" ]; then
        NEW_NAME="${EVAL_OUTPUT_DIR}/eval_${ROUTE_ID}.json"
        cp "$CHECKPOINT_ENDPOINT" "$NEW_NAME"
        echo "Saved: $NEW_NAME"
    else
        echo "Warning: $CHECKPOINT_ENDPOINT not found, skipping save"
    fi
    
    echo "[$CURRENT/$TOTAL] Route $ROUTE_ID completed"
    # Optional early stop for quick validation.
    if [ "${SINGLE_TEST}" = "1" ]; then
        echo "===== SINGLE_TEST_BREAK ====="
        break
    fi
done

echo ""
echo "=========================================="
echo "All $TOTAL routes completed!"
echo "Results saved in: ${EVAL_OUTPUT_DIR}/"
if [ ${#FAILED_ROUTES[@]} -gt 0 ]; then
    # 输出失败路线列表，支持下一次直接重跑（已成功路线会自动跳过）。
    echo "WARNING: ${#FAILED_ROUTES[@]} route(s) failed: ${FAILED_ROUTES[*]}"
    echo "You can re-run the script to retry failed routes (existing results will be skipped)."
else
    echo "All routes succeeded."
fi
echo "=========================================="
