#!/usr/bin/env python
# Copyright (c) 2018-2019 Intel Corporation.
# authors: German Ros (german.ros@intel.com), Felipe Codevilla (felipe.alcm@gmail.com)
#
# This work is licensed under the terms of the MIT license.
# For a copy, see <https://opensource.org/licenses/MIT>.

"""
CARLA 挑战赛路线评测器

用于评估自动驾驶智能体在 CARLA 挑战赛路线任务中的表现

中文说明：
- 本文件是评测主入口，负责把“路线配置 + Agent + 仿真环境”串成完整评测流程。
- 主要职责包括：
    1) 启动/连接 CARLA 与 TrafficManager。
    2) 加载路线与场景，逐条执行 route。
    3) 调用用户 Agent 输出控制指令。
    4) 收集并写入路线级与全局统计结果。
"""
from __future__ import print_function

import traceback
import argparse
from argparse import RawTextHelpFormatter
from distutils.version import LooseVersion
import importlib
import os
import pkg_resources
import sys
import carla
import signal

from srunner.scenariomanager.carla_data_provider import *
from srunner.scenariomanager.timer import GameTime
from srunner.scenariomanager.watchdog import Watchdog

from leaderboard.scenarios.scenario_manager import ScenarioManager
from leaderboard.scenarios.route_scenario import RouteScenario
from leaderboard.envs.sensor_interface import SensorConfigurationInvalid
from leaderboard.autoagents.agent_wrapper import AgentError, validate_sensor_configuration, TickRuntimeError
from leaderboard.utils.statistics_manager import StatisticsManager, FAILURE_MESSAGES
from leaderboard.utils.route_indexer import RouteIndexer
import atexit
import subprocess
import time
import random
from datetime import datetime

sensors_to_icons = {
    'sensor.camera.rgb':        'carla_camera',
    'sensor.lidar.ray_cast':    'carla_lidar',
    'sensor.other.radar':       'carla_radar',
    'sensor.other.gnss':        'carla_gnss',
    'sensor.other.imu':         'carla_imu',
    'sensor.opendrive_map':     'carla_opendrive_map',
    'sensor.speedometer':       'carla_speedometer'
}

import socket

def _is_tcp_port_free(port):
    """判断单个 TCP 端口是否可用（本机 bind 探测）。"""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind(("localhost", port))
            return True
    except OSError:
        return False


def find_free_port(starting_port, block_size=1):
    """从给定起始端口开始，线性探测可用端口（支持连续端口块）。

    说明：
    - block_size=1 时行为与旧实现一致。
    - block_size>1 时，要求 [port, port + block_size - 1] 全部可用。
    - 用于 CARLA 时可规避“RPC 端口可用但其附加端口冲突”的启动崩溃。
    """
    port = starting_port
    while True:
        if all(_is_tcp_port_free(port + offset) for offset in range(block_size)):
            return port
        port += 1

def get_weather_id(weather_conditions):
    """根据当前天气参数匹配 weather.xml 中的 case id。

    返回：
    - 匹配到则返回对应 weather id（字符串）
    - 未匹配到则返回 None
    """
    from xml.etree import ElementTree as ET
    import os
    # weather.xml 保存“天气参数组合 -> weather id”的映射。
    weather_file = os.path.join(os.path.dirname(__file__), '..', 'data', 'weather.xml')
    tree = ET.parse(weather_file)
    root = tree.getroot()
    def conditions_match(weather, conditions):
        for (key, value) in weather:
            if key == 'route_percentage' : continue
            if str(getattr(conditions, key))!= value:
                return False
        return True
    for case in root.findall('case'):
        weather = case[0].items()
        if conditions_match(weather, weather_conditions):
            return case.items()[0][1]
    return None

class LeaderboardEvaluator(object):
    """
    Leaderboard 评测主类。
    从解析输入文件、准备仿真环境到执行路线评测，都由该类统一调度。
    """

    # 可调参数
    client_timeout = 300.0  # in seconds
    frame_rate = 20.0      # in Hz

    def __init__(self, args, statistics_manager):
        """
        初始化 CARLA 客户端与世界对象
        初始化 ScenarioManager
        """
        self.world = None
        self.manager = None
        self.sensors = None
        self.sensors_initialized = False
        self.sensor_icons = []
        self.agent_instance = None
        self.route_scenario = None

        self.statistics_manager = statistics_manager

        # ROS1 bridge 服务实例。
        # 它不封装在 ROS1 agent 内部，因为同一个实例会跨多条路线复用（路线切换时不重启），
        # 以避免服务端与 roslibpy 客户端之间的重连问题。
        self._ros1_server = None

        # 初始化仿真环境
        # 初始化 CARLA 客户端、仿真世界设置与 TrafficManager。
        self.client, self.client_timeout, self.traffic_manager = self._setup_simulation(args)

        dist = pkg_resources.get_distribution("carla")
        if dist.version != 'leaderboard':
            if LooseVersion(dist.version) < LooseVersion('0.9.10'):
                raise ImportError("CARLA version 0.9.10.1 or newer required. CARLA version found: {}".format(dist))

        # 加载 Agent
        # 动态导入用户提供的 agent Python 文件。
        # 示例：--agent=leaderboard/team_code/mot_b2d_agent.py
        module_name = os.path.basename(args.agent).split('.')[0]
        sys.path.insert(0, os.path.dirname(args.agent))
        self.module_agent = importlib.import_module(module_name)

        # 创建 ScenarioManager
        self.manager = ScenarioManager(args.timeout, self.statistics_manager, args.debug)

        # 用于最终汇总统计的时间控制
        self._start_time = GameTime.get_time()
        self._end_time = None

        # 初始化 Agent 超时看门狗
        self._agent_watchdog = None
        signal.signal(signal.SIGINT, self._signal_handler)

        self._client_timed_out = False

    def _signal_handler(self, signum, frame):
        """
        收到中断信号时终止场景 tick。
        可能来源于 Agent 初始化阶段看门狗，或 ScenarioManager 运行阶段看门狗。
        """
        if self._agent_watchdog and not self._agent_watchdog.get_status():
            raise RuntimeError("Timeout: Agent took longer than {}s to setup".format(self.client_timeout))
        elif self.manager:
            # 运行阶段的信号交给 ScenarioManager 处理（其内部也有 watchdog 保护）。
            self.manager.signal_handler(signum, frame)

    def __del__(self):
        """
        清理并释放演员对象、ScenarioManager 与 CARLA 世界对象
        """
        if hasattr(self, 'manager') and self.manager:
            del self.manager
        if hasattr(self, 'world') and self.world:
            del self.world

    def _get_running_status(self):
        """
          返回：
              bool：看门狗异常时为 False，否则为 True
        """
        if self._agent_watchdog:
            return self._agent_watchdog.get_status()
        return False

    def _cleanup(self):
        """
        清理并销毁所有演员对象与相关运行资源
        """
        CarlaDataProvider.cleanup()

        if self._agent_watchdog:
            self._agent_watchdog.stop()

        try:
            if self.agent_instance:
                # 释放用户 Agent 资源（模型、缓存、文件句柄等）。
                self.agent_instance.destroy()
                self.agent_instance = None
        except Exception as e:
            print("\n\033[91mFailed to stop the agent:", flush=True)
            print(f"\n{traceback.format_exc()}\033[0m", flush=True)

        if self.route_scenario:
            self.route_scenario.remove_all_actors()
            self.route_scenario = None
            if self.statistics_manager:
                self.statistics_manager.remove_scenario()

        if self.manager:
            self._client_timed_out = not self.manager.get_running_status()
            self.manager.cleanup()

        # 确保没有传感器残留推流
        # 兜底清理：防止残留传感器持续推流导致后续路线异常。
        alive_sensors = self.world.get_actors().filter('*sensor*')
        for sensor in alive_sensors:
            sensor.stop()
            sensor.destroy()

    def _setup_simulation(self, args):
        """
        准备仿真环境：创建客户端并配置世界与 TrafficManager 参数
        """
        # 若未设置 CARLA_ROOT 则自动探测
        carla_root = os.environ.get("CARLA_ROOT")
        if not carla_root:
            # 尝试常见安装目录
            script_dir = os.path.dirname(os.path.abspath(__file__))
            project_root = os.path.dirname(os.path.dirname(script_dir))
            candidates = [
                os.path.join(os.path.dirname(project_root), 'carla'),
                os.path.expanduser('~/carla'),
            ]
            for candidate in candidates:
                if os.path.isfile(os.path.join(candidate, 'CarlaUE4.sh')):
                    carla_root = candidate
                    os.environ["CARLA_ROOT"] = carla_root
                    print(f"Auto-detected CARLA_ROOT={carla_root}", flush=True)
                    break
            if not carla_root:
                raise EnvironmentError(
                    "CARLA_ROOT is not set and could not be auto-detected. "
                    "Please export CARLA_ROOT=/path/to/carla"
                )
        self.carla_path = carla_root
        # CARLA 除 RPC 端口外还会占用附加端口，单端口探测不够稳妥。
        # 这里预留连续 4 个端口，减少 Address already in use 概率。
        args.port = find_free_port(args.port, block_size=4)
        streaming_port = args.port + 1
        # cmd1 = f"{os.path.join(self.carla_path, 'CarlaUE4.sh')} -RenderOffScreen -nosound -quality-level=Low -carla-rpc-port={args.port}"
        # RenderOffScreen + nosound：更适合服务器/无显示环境。
        cmd1 = (
            f"{os.path.join(self.carla_path, 'CarlaUE4.sh')} "
            f"-RenderOffScreen -nosound "
            f"-carla-rpc-port={args.port} "
            f"-carla-streaming-port={streaming_port} "
            f"-graphicsadapter={args.gpu_rank}"
        )
        self.server = subprocess.Popen(cmd1, shell=True, preexec_fn=os.setsid)
        print(f"Launch CARLA: {cmd1}", flush=True)
        print(f"CARLA pid={self.server.pid}", flush=True)
        # 注册退出回调，确保主进程结束时 Carla 进程组被回收。
        atexit.register(os.killpg, self.server.pid, signal.SIGKILL)
        # 给 Carla 服务预留冷启动时间。
        time.sleep(30)
            
        attempts = 0
        num_max_restarts = 20
        while attempts < num_max_restarts:
            try:
                client = carla.Client(args.host, args.port)
                if args.timeout:
                    # CLI 显式传入超时值时，覆盖类默认 client_timeout。
                    client_timeout = args.timeout
                client.set_timeout(client_timeout)

                settings = carla.WorldSettings(
                    synchronous_mode = True,
                    fixed_delta_seconds = 1.0 / self.frame_rate,
                    deterministic_ragdolls = True,
                    spectator_as_ego = False
                )
                client.get_world().apply_settings(settings)
                print(f"load_world success , attempts={attempts}", flush=True)
                break
            except Exception as e:
                # 世界初始化失败时重试，常见于服务刚启动尚未完全就绪。
                print(f"load_world failed , attempts={attempts}", flush=True)
                print(e, flush=True)
                attempts += 1
                time.sleep(5)

        # 注意：若循环耗尽仍未成功，这里会依赖后续代码触发异常；保持原实现行为不变。
        attempts = 0
        num_max_restarts = 40
        while attempts < num_max_restarts:
            try:
                # TM 端口也做可用性探测，避免多个评测任务并行时冲突。
                args.traffic_manager_port = find_free_port(args.traffic_manager_port)
                traffic_manager = client.get_trafficmanager(args.traffic_manager_port)
                traffic_manager.set_synchronous_mode(True)
                traffic_manager.set_hybrid_physics_mode(True)
                print(f"traffic_manager init success, try_time={attempts}", flush=True)
                break
            except Exception as e:
                print(f"traffic_manager init fail, try_time={attempts}", flush=True)
                print(e, flush=True)
                attempts += 1
                time.sleep(5)

            # 返回三元组供 __init__ 保存：CARLA client、超时时间、TrafficManager 实例。
        return client, client_timeout, traffic_manager

    def _reset_world_settings(self):
        """
        将被修改的世界设置恢复为异步模式
        """
        # 仿真是否已失败
        if self.world and self.manager and not self._client_timed_out:
            # 恢复为异步模式
            self.world.tick()  # TODO: Make sure all scenario actors have been destroyed
            settings = self.world.get_settings()
            settings.synchronous_mode = False
            settings.fixed_delta_seconds = None
            settings.deterministic_ragdolls = False
            settings.spectator_as_ego = True
            self.world.apply_settings(settings)

            # 将 TrafficManager 也恢复为异步
            self.traffic_manager.set_synchronous_mode(False)
            self.traffic_manager.set_hybrid_physics_mode(False)

    def _load_and_wait_for_world(self, args, town):
        """
        加载新的 CARLA 世界（保持现有设置），并向 CarlaDataProvider 注入上下文
        """
        self.world = self.client.load_world(town, reset_settings=False)

        # 大地图相关设置在 load_world 后会被重置，这里需要重新设定
        settings = self.world.get_settings()
        settings.tile_stream_distance = 650
        settings.actor_active_distance = 650
        self.world.apply_settings(settings)

        self.world.reset_all_traffic_lights()
        CarlaDataProvider.set_client(self.client)
        CarlaDataProvider.set_traffic_manager_port(args.traffic_manager_port)
        CarlaDataProvider.set_world(self.world)

        # 需在此处设置，保证同一路线多次重复时使用一致随机种子
        # 固定 TM 随机种子，保证同一路线重复运行时交通参与者行为更可复现。
        self.traffic_manager.set_random_device_seed(args.traffic_manager_seed)

        # 等待世界完成一帧更新，确保环境就绪
        self.world.tick()

        map_name = CarlaDataProvider.get_map().name.split("/")[-1]
        if map_name != town:
            # 防止“路线要求地图”和“当前仿真地图”不一致导致评测失真。
            raise Exception("The CARLA server uses the wrong map!"
                            " This scenario requires the use of map {}".format(town))

    def _register_statistics(self, route_index, entry_status, crash_message=""):
        """
        计算并保存当前路线统计信息
        """
        print("\033[1m> Registering the route statistics\033[0m", flush=True)
        self.statistics_manager.save_entry_status(entry_status)
        self.statistics_manager.compute_route_statistics(
            route_index, self.manager.scenario_duration_system, self.manager.scenario_duration_game, crash_message
        )

    def _load_and_run_scenario(self, args, config):
        """
        按给定配置加载并运行场景。

        根据失败类型不同，流程可能：
        1) 仅结束当前路线并继续下一条；
        2) 上报仿真崩溃并停止整体评测。
        """
        crash_message = ""
        entry_status = "Started"

        print("\n\033[1m========= Preparing {} (repetition {}) =========\033[0m".format(config.name, config.repetition_index), flush=True)

        # 准备该路线的统计元信息
        # save_name 用于把路线名、城市场景、天气、时间戳编码进输出目录/文件名，便于追踪。
        route_name = f"{config.name}_rep{config.repetition_index}"
        scenario_name = config.scenario_configs[0].name
        town_name = str(config.town)
        weather_id = get_weather_id(config.weather[0][1])
        currentDateAndTime = datetime.now()
        currentTime = currentDateAndTime.strftime("%m_%d_%H_%M_%S")
        save_name = f"{route_name}_{town_name}_{scenario_name}_{weather_id}_{currentTime}"
        self.statistics_manager.create_route_data(route_name, scenario_name, weather_id, save_name, town_name, config.index)

        print("\033[1m> Loading the world\033[0m", flush=True)

        # 加载世界与场景
        try:
            self._load_and_wait_for_world(args, config.town)
            self.route_scenario = RouteScenario(world=self.world, config=config, debug_mode=args.debug)
            self.statistics_manager.set_scenario(self.route_scenario)

        except Exception:
            # 场景加载失败：登记为仿真失败并结束当前路线
            print("\n\033[91mThe scenario could not be loaded:", flush=True)
            print(f"\n{traceback.format_exc()}\033[0m", flush=True)

            entry_status, crash_message = FAILURE_MESSAGES["Simulation"]
            self._register_statistics(config.index, entry_status, crash_message)
            self._cleanup()
            return True

        print("\033[1m> Setting up the agent\033[0m", flush=True)

        # 初始化用户 Agent，并用看门狗避免初始化卡死
        try:
            # Agent 初始化阶段也受 watchdog 保护，防止 setup 卡死。
            self._agent_watchdog = Watchdog(args.timeout)
            self._agent_watchdog.start()
            agent_class_name = getattr(self.module_agent, 'get_entry_point')()
            agent_class_obj = getattr(self.module_agent, agent_class_name)

            # 仅对 ROS1 Agent 启动 ROS1 bridge 服务。
            if getattr(agent_class_obj, 'get_ros_version')() == 1 and self._ros1_server is None:
                from leaderboard.autoagents.ros1_agent import ROS1Server
                self._ros1_server = ROS1Server()
                self._ros1_server.start()

            self.agent_instance = agent_class_obj(args.host, args.port, args.debug)
            self.agent_instance.set_global_plan(self.route_scenario.gps_route, self.route_scenario.route)
            # 将本次运行的唯一标识拼接到 agent_config 末尾，便于下游按路线保存产物。
            args.agent_config = args.agent_config + '+' + save_name
            self.agent_instance.setup(args.agent_config)

            # 校验并记录传感器配置
            if not self.sensors:
                # 仅在首次路线时保存传感器配置，避免重复写入。
                self.sensors = self.agent_instance.sensors()
                track = self.agent_instance.track

                validate_sensor_configuration(self.sensors, track, args.track)

                self.sensor_icons = [sensors_to_icons[sensor['type']] for sensor in self.sensors]
                self.statistics_manager.save_sensors(self.sensor_icons)
                self.statistics_manager.write_statistics()

                self.sensors_initialized = True

            self._agent_watchdog.stop()
            self._agent_watchdog = None

        except SensorConfigurationInvalid as e:
            # 传感器配置不合法：标记拒绝并结束当前路线
            print("\n\033[91mThe sensor's configuration used is invalid:", flush=True)
            print(f"{e}\033[0m\n", flush=True)

            entry_status, crash_message = FAILURE_MESSAGES["Sensors"]
            self._register_statistics(config.index, entry_status, crash_message)
            self._cleanup()
            return True

        except Exception as e:
            # Agent 初始化失败：记录失败并继续后续流程
            print("\n\033[91mCould not set up the required agent:", flush=True)
            print(f"\n{traceback.format_exc()}\033[0m", flush=True)
            print(f"{e}\033[0m\n", flush=True)

            entry_status, crash_message = FAILURE_MESSAGES["Agent_init"]
            self._register_statistics(config.index, entry_status, crash_message)
            self._cleanup()
            return True

        print("\033[1m> Running the route\033[0m", flush=True)

        # 运行场景，和agent循环交互
        try:
            # 加载场景并开始执行
            if args.record:
                # 可选录制 CARLA 原生日志，便于后处理回放。
                self.client.start_recorder("{}/{}_rep{}.log".format(args.record, config.name, config.repetition_index))
            self.manager.load_scenario(self.route_scenario, self.agent_instance, config.index, config.repetition_index)
            self.manager.tick_count = 0
            self.manager.run_scenario()

        except AgentError:
            # Agent 运行时崩溃：停止当前路线
            print("\n\033[91mStopping the route, the agent has crashed:", flush=True)
            print(f"\n{traceback.format_exc()}\033[0m")

            entry_status, crash_message = FAILURE_MESSAGES["Agent_runtime"]

        except KeyboardInterrupt:
            # 人工中断时直接上抛“需要终止当前执行”的语义给上层。
            return True
        
        except TickRuntimeError:
            # Tick 级异常单独标注，便于与 Agent 崩溃、仿真崩溃区分。
            entry_status, crash_message = "Started", "TickRuntime"
        
        except Exception:
            print("\n\033[91mError during the simulation:", flush=True)
            print(f"\n{traceback.format_exc()}\033[0m", flush=True)

            entry_status, crash_message = FAILURE_MESSAGES["Simulation"]

        # 停止场景并写入统计
        try:
            print("\033[1m> Stopping the route\033[0m", flush=True)
            self.manager.stop_scenario()
            self._register_statistics(config.index, entry_status, crash_message)

            if args.record:
                self.client.stop_recorder()

            self._cleanup()

        except Exception:
            print("\n\033[91mFailed to stop the scenario, the statistics might be empty:", flush=True)
            print(f"\n{traceback.format_exc()}\033[0m", flush=True)

            _, crash_message = FAILURE_MESSAGES["Simulation"]

        # 若为仿真级崩溃则停止 Leaderboard；否则继续下一条路线
        # True 表示“仿真级崩溃”，上层应终止总流程并等待人工介入。
        return crash_message == "Simulation crashed"

    def run(self, args):
        """
        运行挑战赛评测主流程
        """
        route_indexer = RouteIndexer(args.routes, args.repetitions, args.routes_subset)

        if args.resume:
            # resume=True 时从 checkpoint 中恢复进度与历史记录。
            resume = route_indexer.validate_and_resume(args.checkpoint)
        else:
            resume = False

        if resume:
            self.statistics_manager.add_file_records(args.checkpoint)
        else:
            self.statistics_manager.clear_records()
        self.statistics_manager.save_progress(route_indexer.index, route_indexer.total)
        self.statistics_manager.write_statistics()

        crashed = False
        t1 = time.time()
        while route_indexer.peek() and not crashed:

            # 执行当前路线对应场景
            config = route_indexer.get_next_config()
            crashed = self._load_and_run_scenario(args, config)
            print(crashed, flush=True)
            # 保存当前进度并持久化路线统计
            self.statistics_manager.save_progress(route_indexer.index, route_indexer.total)
            self.statistics_manager.write_statistics()
            if crashed:
                print(f'{route_indexer.index} crash, [{route_indexer.index}/{route_indexer.total}], please restart', flush=True)
                break

        # 如有需要，关闭 ROS1 bridge 服务
        if self._ros1_server is not None:
            self._ros1_server.shutdown()

        # 恢复异步世界设置
        self._reset_world_settings()

        if not crashed:
            # 计算并保存全局统计
            print(f"cost time={time.time()-t1}", flush=True)
            print("\033[1m> Registering the global statistics\033[0m", flush=True)
            self.statistics_manager.compute_global_statistics()
            self.statistics_manager.validate_and_write_statistics(self.sensors_initialized, crashed)
        
        if crashed:
            # 仿真崩溃后尝试清理对应 GPU 的 Carla 进程，避免僵尸进程占用资源。
            cmd2 = "ps -ef | grep '-graphicsadapter="+ str(args.gpu_rank) + "' | grep -v grep | awk '{print $2}' | xargs -r kill -9"
            server = subprocess.Popen(cmd2, shell=True, preexec_fn=os.setsid)
            atexit.register(os.killpg, server.pid, signal.SIGKILL)

        return crashed

def main():
    description = "CARLA AD Leaderboard Evaluation: evaluate your Agent in CARLA scenarios\n"

    # 通用参数
    # 参数分组说明：
    # 1) CARLA/TrafficManager 连接参数
    # 2) 路线与重复次数参数
    # 3) Agent 文件、配置与输出参数
    parser = argparse.ArgumentParser(description=description, formatter_class=RawTextHelpFormatter)
    parser.add_argument('--host', default='localhost',
                        help='IP of the host server (default: localhost)')
    parser.add_argument('--port', default=2000, type=int,
                        help='TCP port to listen to (default: 2000)')
    parser.add_argument('--traffic-manager-port', default=8000, type=int,
                        help='Port to use for the TrafficManager (default: 8000)')
    parser.add_argument('--traffic-manager-seed', default=0, type=int,
                        help='Seed used by the TrafficManager (default: 0)')
    parser.add_argument('--debug', type=int,
                        help='Run with debug output', default=0)
    parser.add_argument('--record', type=str, default='',
                        help='Use CARLA recording feature to create a recording of the scenario')
    parser.add_argument('--timeout', default=1200.0, type=float,
                        help='Set the CARLA client timeout value in seconds')

    # 仿真设置参数
    parser.add_argument('--routes', required=True,
                        help='Name of the routes file to be executed.')
    parser.add_argument('--routes-subset', default='', type=str,
                        help='Execute a specific set of routes')
    parser.add_argument('--repetitions', type=int, default=1,
                        help='Number of repetitions per route.')

    # Agent 相关参数
    parser.add_argument("-a", "--agent", type=str,
                        help="Path to Agent's py file to evaluate", required=True)
    parser.add_argument("--agent-config", type=str,
                        help="Path to Agent's configuration file", default="")

    parser.add_argument("--track", type=str, default='SENSORS',
                        help="Participation track: SENSORS, MAP")
    parser.add_argument('--resume', type=bool, default=False,
                        help='Resume execution from last checkpoint?')
    parser.add_argument("--checkpoint", type=str, default='./simulation_results.json',
                        help="Path to checkpoint used for saving statistics and resuming")
    parser.add_argument("--debug-checkpoint", type=str, default='./live_results.txt',
                        help="Path to checkpoint used for saving live results")
    parser.add_argument("--gpu-rank", type=int, default=0)

    # 解析命令行参数，产出 argparse.Namespace（后续会作为全局配置对象传递）。
    arguments = parser.parse_args()
    # host='localhost', port=5000, traffic_manager_port=13000, traffic_manager_seed=3407, 
    # debug=0, record='', timeout=1200.0, 
    # routes='/home/cruser1/lda/AutoMoT/leaderboard/data/bench2drive220.xml', 
    # routes_subset='1773', repetitions=1, agent='leaderboard/team_code/mot_b2d_agent.py', 
    # agent_config='/home/cruser1/lda/AutoMoT/Automot/checkpoints+automot_eval', track='SENSORS', 
    # resume=False, checkpoint='/home/cruser1/lda/AutoMoT/outputs/leaderboard/v_2json_open/eval_latest.json', 
    # debug_checkpoint='./live_results.txt', gpu_rank=0)

    # 1) 创建统计管理器：负责评测进度、单路线结果、全局指标写入 checkpoint/debug 文件。
    statistics_manager = StatisticsManager(arguments.checkpoint, arguments.debug_checkpoint)
    # 2) 创建评测执行器：初始化 CARLA/TrafficManager、加载 Agent，并绑定统计管理器。
    leaderboard_evaluator = LeaderboardEvaluator(arguments, statistics_manager)
    # 3) 正式运行评测主循环：按 routes 执行，返回是否发生“仿真级崩溃”标记。
    crashed = leaderboard_evaluator.run(arguments)

    del leaderboard_evaluator

    if crashed:
        sys.exit(-1)
    else:
        sys.exit(0)

def attach_debugger():
    import debugpy
    debugpy.listen(5678)
    print("Waiting for debugger!")
    debugpy.wait_for_client()
    print("Attached!")

if __name__ == '__main__':
    # 26435 26393 2534 1833 1852 24258
    # attach_debugger()  
    # 从这里进入程序主流程。
    main()
