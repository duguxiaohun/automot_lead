#!/usr/bin/env python

# Copyright (c) 2018-2020 Intel Corporation
#
# This work is licensed under the terms of the MIT license.
# For a copy, see <https://opensource.org/licenses/MIT>.

"""
场景管理器模块。

作用：
- 承接评测器传入的 route 场景与 agent，驱动 CARLA tick 循环。
- 在每个 tick 中完成“读取传感器 -> 调 agent -> 下发控制 -> 推进行为树”。
- 维护看门狗、统计时长、调试输出与结束清理。
"""

from __future__ import print_function
import signal
import sys
import time

import py_trees
import carla
import threading

from srunner.scenariomanager.carla_data_provider import CarlaDataProvider
from srunner.scenariomanager.timer import GameTime
from srunner.scenariomanager.watchdog import Watchdog

from leaderboard.autoagents.agent_wrapper import AgentWrapperFactory, AgentError, TickRuntimeError
from leaderboard.envs.sensor_interface import SensorReceivedNoData
from leaderboard.utils.result_writer import ResultOutputProvider


class ScenarioManager(object):

    """
    场景管理核心类。

典型使用流程：
1. 创建对象：manager = ScenarioManager(...)
2. 加载场景：manager.load_scenario(...)
3. 启动执行：manager.run_scenario()
4. 结束清理：manager.stop_scenario()
    """

    def __init__(self, timeout, statistics_manager, debug_mode=0):
        """
        初始化运行期状态。
        与具体路线绑定的字段（如 scenario_tree、ego_vehicles）会在 load_scenario() 中填充。
        """
        self.route_index = None
        self.scenario = None
        self.scenario_tree = None
        self.ego_vehicles = None
        self.other_actors = None

        # debug_mode 控制调试输出级别：
        # 0: 基础运行
        # 1: 启用场景构建调试参数
        # 2+: 额外输出实时统计
        # 3+: 打印行为树 ASCII 结构
        self._debug_mode = debug_mode
        self._agent_wrapper = None
        self._running = False
        # 记录上次处理的仿真时间戳，避免同一帧重复执行逻辑。
        self._timestamp_last_run = 0.0
        self._timeout = float(timeout)

        # 系统时间与仿真时间分开统计：
        # - system: 墙钟时间（真实耗时）
        # - game  : CARLA 游戏时钟（仿真时间）
        self.scenario_duration_system = 0.0
        self.scenario_duration_game = 0.0
        self.start_system_time = 0.0
        self.start_game_time = 0.0
        self.end_system_time = 0.0
        self.end_game_time = 0.0

        self._watchdog = None
        self._agent_watchdog = None
        self._scenario_thread = None

        # 评测统计写入器（路线分数、实时调试信息等）。
        self._statistics_manager = statistics_manager

        # 当前路线累计 tick 计数，用于超长运行保护。
        self.tick_count = 0

        # Use the callback_id inside the signal handler to allow external interrupts
        # 捕获 Ctrl+C，避免主循环卡住时无法优雅退出。
        signal.signal(signal.SIGINT, self.signal_handler)

    def signal_handler(self, signum, frame):
        """
        收到中断信号时终止场景循环。

        若中断实质由看门狗触发，则抛出更明确的超时异常信息。
        """
        if self._agent_watchdog and not self._agent_watchdog.get_status():
            raise RuntimeError("Agent took longer than {}s to send its command".format(self._timeout))
        elif self._watchdog and not self._watchdog.get_status():
            raise RuntimeError("The simulation took longer than {}s to update".format(self._timeout))
        # 正常中断信号下终止运行循环。
        self._running = False

    def cleanup(self):
        """
        重置运行期状态（不负责销毁 scenario 本体，由 stop_scenario 处理）。
        """
        self._timestamp_last_run = 0.0
        self.scenario_duration_system = 0.0
        self.scenario_duration_game = 0.0
        self.start_system_time = 0.0
        self.start_game_time = 0.0
        self.end_system_time = 0.0
        self.end_game_time = 0.0

        self._spectator = None
        self._watchdog = None
        self._agent_watchdog = None

    def load_scenario(self, scenario, agent, route_index, rep_number):
        """
        加载新场景并绑定 agent。

        主要工作：
        - 重置 GameTime
        - 包装 agent（注入传感器读取与异常处理）
        - 缓存场景树、车辆列表、路线索引
        - 初始化 ego 传感器
        """

        GameTime.restart()
        self._agent_wrapper = AgentWrapperFactory.get_wrapper(agent)
        self.route_index = route_index
        self.scenario = scenario
        self.scenario_tree = scenario.scenario_tree
        self.ego_vehicles = scenario.ego_vehicles
        self.other_actors = scenario.other_actors
        self.repetition_number = rep_number

        self._spectator = CarlaDataProvider.get_world().get_spectator()

        # 如需导出行为树图，可取消下一行注释。
        # py_trees.display.render_dot_tree(self.scenario_tree)

        # 在 ego 上挂载并启动本路线需要的全部传感器。
        self._agent_wrapper.setup_sensors(self.ego_vehicles[0])

    def build_scenarios_loop(self, debug):
        """
        后台线程循环：周期性尝试构建临近 ego 的动态场景，并补充停放车辆。
        该线程与主 tick 线程并行运行，降低主循环负担。
        """
        while self._running:
            # 动态触发“接近 ego 的场景”和“可生成的静态车辆”，减少一次性加载压力。
            self.scenario.build_scenarios(self.ego_vehicles[0], debug=debug)
            self.scenario.spawn_parked_vehicles(self.ego_vehicles[0])
            time.sleep(1)

    def run_scenario(self):
        """
        启动并阻塞运行当前场景，直到结束或失败。
        """
        self.start_system_time = time.time()
        self.start_game_time = GameTime.get_time()

        # 仿真看门狗：检测 world.tick 卡死。
        # 仿真 watchdog：保护 world tick，超时视为仿真异常。
        self._watchdog = Watchdog(self._timeout)
        self._watchdog.start()

        # Agent 看门狗：检测 agent 计算卡死。
        # agent watchdog：保护 Agent 推理与控制输出，避免卡死主循环。
        self._agent_watchdog = Watchdog(self._timeout)
        self._agent_watchdog.start()

        self._running = True

        # 场景构建后台线程
        # 后台线程负责持续检查并构建临近场景；主线程专注 tick 与控制闭环。
        self._scenario_thread = threading.Thread(target=self.build_scenarios_loop, args=(self._debug_mode > 0, ))
        self._scenario_thread.start()

        # tick 循环，持续交互 agent 和场景，直到场景结束或异常中断。
        while self._running:
            self._tick_scenario()

    def _tick_scenario(self):
        """
        执行一次完整 tick：
        1) 推进 CARLA 世界一帧
        2) 更新 GameTime 与 DataProvider
        3) 调用 agent 获取控制量
        4) apply_control 到 ego
        5) 推进行为树并检查结束条件
        """
        if self._running and self.get_running_status():
            CarlaDataProvider.get_world().tick(self._timeout)

        timestamp = CarlaDataProvider.get_world().get_snapshot().timestamp

        if self._timestamp_last_run < timestamp.elapsed_seconds and self._running:
            self._timestamp_last_run = timestamp.elapsed_seconds

            self._watchdog.update()
            # 同步游戏时钟与演员缓存（供下游场景条件判断使用）。
            GameTime.on_carla_tick(timestamp)
            CarlaDataProvider.on_carla_tick()
            self.tick_count += 1
            self._watchdog.pause()

            if self.tick_count > 4000:
                # 单路线安全阈值：防止异常路线无限运行导致任务挂死。
                raise TickRuntimeError("RuntimeError, tick_count > 4000")

            try:
                self._agent_watchdog.resume()
                self._agent_watchdog.update()
                # 调用包装后的 agent，产出当前时刻车辆控制量。
                ego_action = self._agent_wrapper()
                self._agent_watchdog.pause()

            # 该异常表示“传感器当前帧未拿到数据”，不一定是 agent 本身逻辑错误。
            except SensorReceivedNoData as e:
                raise RuntimeError(e)

            # 其余异常视为 AgentError，由上层统一统计与处置。
            except Exception as e:
                raise AgentError(e)

            self._watchdog.resume()
            self.ego_vehicles[0].apply_control(ego_action)

            # 将控制写入 blackboard，便于行为树节点读取/修改 AV 控制。
            py_trees.blackboard.Blackboard().set("AV_control", ego_action, overwrite=True)
            self.scenario_tree.tick_once()

            if self._debug_mode > 1:
                self.compute_duration_time()

                # 调试模式下实时刷新路线统计与 live 文本。
                self._statistics_manager.compute_route_statistics(
                    self.route_index,
                    self.scenario_duration_system,
                    self.scenario_duration_game,
                    failure_message=""
                )
                self._statistics_manager.write_live_results(
                    self.route_index,
                    self.ego_vehicles[0].get_velocity().length(),
                    ego_action,
                    self.ego_vehicles[0].get_location()
                )

            if self._debug_mode > 2:
                # 打印行为树当前状态，便于定位卡住节点。
                print("\n")
                py_trees.display.print_ascii_tree(self.scenario_tree, show_status=True)
                sys.stdout.flush()

            if self.scenario_tree.status != py_trees.common.Status.RUNNING:
                # 行为树不再 RUNNING 表示场景结束（成功或失败）。
                self._running = False

            ego_trans = self.ego_vehicles[0].get_transform()
            # 将观测相机切到俯视 ego 的视角，便于调试观察。
            self._spectator.set_transform(carla.Transform(ego_trans.location + carla.Location(z=70),
                                                          carla.Rotation(pitch=-90)))

    def get_running_status(self):
        """
          返回：
              bool：看门狗异常时为 False，否则为 True
        """
        if self._watchdog:
            return self._watchdog.get_status()
        return True

    def stop_scenario(self):
        """
        触发场景的规范化终止流程。

        包含：
        - 停止看门狗
        - 统计时长收尾
        - 终止场景与清理 agent wrapper
        - 输出分析结果
        - 回收后台线程
        """
        if self._watchdog:
            self._watchdog.stop()

        if self._agent_watchdog:
            self._agent_watchdog.stop()

        self.compute_duration_time()

        if self.get_running_status():
            if self.scenario is not None:
                self.scenario.terminate()

            if self._agent_wrapper is not None:
                self._agent_wrapper.cleanup()
                self._agent_wrapper = None

            self.analyze_scenario()

        # 确保后台线程退出，防止 join 阻塞或资源泄漏。
        self._running = False
        self._scenario_thread.join()
        self._scenario_thread = None

    def compute_duration_time(self):
        """
        计算系统耗时与仿真耗时
        """
        self.end_system_time = time.time()
        self.end_game_time = GameTime.get_time()

        self.scenario_duration_system = self.end_system_time - self.start_system_time
        self.scenario_duration_game = self.end_game_time - self.start_game_time

    def analyze_scenario(self):
        """
        输出当前路线分析结果
        """
        ResultOutputProvider(self)
