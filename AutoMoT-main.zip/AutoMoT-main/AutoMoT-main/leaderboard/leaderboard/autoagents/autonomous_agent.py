#!/usr/bin/env python

# This work is licensed under the terms of the MIT license.
# For a copy, see <https://opensource.org/licenses/MIT>.

"""
自动驾驶 Agent 基类模块。

说明：
- 用户自定义 Agent 需要继承本文件中的 AutonomousAgent。
- 评测框架会通过 __call__() 统一驱动 Agent，内部再调用 run_step() 输出控制量。
- 该类同时维护路线、传感器接口与一些通用辅助方法。
"""

from __future__ import print_function

from enum import Enum

import carla
from srunner.scenariomanager.timer import GameTime

from leaderboard.utils.route_manipulation import downsample_route
from leaderboard.envs.sensor_interface import SensorInterface


class Track(Enum):

    """
    CARLA Leaderboard 赛道类型枚举。

    各项含义：
    - SENSORS: 仅允许传感器输入（相机/LiDAR/Radar/GPS/IMU 等）。
    - MAP: 在 SENSORS 基础上允许使用 OpenDRIVE 地图信息。
    - *_QUALIFIER: 资格赛对应赛道类型。
    """
    SENSORS = 'SENSORS'
    MAP = 'MAP'
    SENSORS_QUALIFIER = 'SENSORS_QUALIFIER'
    MAP_QUALIFIER = 'MAP_QUALIFIER'


class AutonomousAgent(object):

    """
    自动驾驶 Agent 抽象基类。

    用户 Agent 应覆写的方法：
    - setup(): 初始化模型、配置、缓存等。
    - sensors(): 声明所需传感器列表。
    - run_step(): 每个 tick 的决策逻辑，返回 carla.VehicleControl。
    """

    def __init__(self, carla_host, carla_port, debug=False):
        self.track = Track.SENSORS
        # 当前全局路径（降采样后）
        # _global_plan: GPS 路径点
        # _global_plan_world_coord: 世界坐标路径点 + 路段选项
        self._global_plan = None
        self._global_plan_world_coord = None

        # 传感器数据统一入口（每个 tick 从这里读取当前帧各传感器数据）
        self.sensor_interface = SensorInterface()

        # 记录首次 wallclock 时间，用于打印“仿真时间/真实时间倍率”
        self.wallclock_t0 = None

        # 尝试缓存 hero 车辆对象，便于后续 metric 信息提取。
        self.get_hero()

    def setup(self, path_to_conf_file):
        """
        初始化 Agent 所需资源，并设置正确赛道类型。

        赛道约束：
        - Track.SENSORS: 允许相机、LiDAR、Radar、GPS、IMU 等传感器。
        - Track.MAP: 允许在 SENSORS 基础上额外使用 OpenDRIVE 地图。
        """
        pass

    def sensors(self):  # pylint: disable=no-self-use
        """
        定义 Agent 所需传感器配置。

        返回：
        - list，元素为传感器字典，格式示例如下

        [
            {'type': 'sensor.camera.rgb', 'x': 0.7, 'y': -0.4, 'z': 1.60, 'roll': 0.0, 'pitch': 0.0, 'yaw': 0.0,
                      'width': 300, 'height': 200, 'fov': 100, 'id': 'Left'},

            {'type': 'sensor.camera.rgb', 'x': 0.7, 'y': 0.4, 'z': 1.60, 'roll': 0.0, 'pitch': 0.0, 'yaw': 0.0,
                      'width': 300, 'height': 200, 'fov': 100, 'id': 'Right'},

            {'type': 'sensor.lidar.ray_cast', 'x': 0.7, 'y': 0.0, 'z': 1.60, 'yaw': 0.0, 'pitch': 0.0, 'roll': 0.0,
             'id': 'LIDAR'}
        ]

        """
        sensors = []

        return sensors

    def run_step(self, input_data, timestamp):
        """
        执行一次决策步。

        参数：
        - input_data: 当前帧传感器数据字典。
        - timestamp: 当前仿真时间（秒）。

        返回：
        - carla.VehicleControl 控制指令。

        默认实现返回全零控制，仅作为占位示例。
        """
        control = carla.VehicleControl()
        control.steer = 0.0
        control.throttle = 0.0
        control.brake = 0.0
        control.hand_brake = False

        return control

    def destroy(self):
        """
        销毁并清理 Agent 资源。

        可在子类中释放模型显存、关闭文件句柄、停止外部服务等。
        """
        pass

    def __call__(self):
        """
        统一的 Agent 调用入口（框架每个 tick 调用一次）。

        流程：
        1) 从 sensor_interface 读取当前帧传感器数据
        2) 获取仿真时间并计算仿真倍率
        3) 调用 run_step() 得到控制指令
        4) 强制关闭手动换挡并返回控制
        """
        input_data = self.sensor_interface.get_data(GameTime.get_frame())

        timestamp = GameTime.get_time()

        if not self.wallclock_t0:
            self.wallclock_t0 = GameTime.get_wallclocktime()
        wallclock = GameTime.get_wallclocktime()
        wallclock_diff = (wallclock - self.wallclock_t0).total_seconds()
        sim_ratio = 0 if wallclock_diff == 0 else timestamp/wallclock_diff

        print('=== [Agent] -- Wallclock = {} -- System time = {} -- Game time = {} -- Ratio = {}x'.format(
            str(wallclock)[:-3], format(wallclock_diff, '.3f'), format(timestamp, '.3f'), format(sim_ratio, '.3f')), flush=True)

        control = self.run_step(input_data, timestamp)
        control.manual_gear_shift = False

        return control

    @staticmethod
    def get_ros_version():
        # 默认非 ROS Agent；子类可覆写为 1（ROS1）或其他约定值。
        return -1

    def set_global_plan(self, global_plan_gps, global_plan_world_coord):
        """
        设置 Agent 的全局规划路径（route）。

        说明：
        - 输入路径通常较密集，这里会按固定步长降采样（downsample_route）。
        - 同时保存 GPS 版本与世界坐标版本，供不同模块按需使用。
        """
        ds_ids = downsample_route(global_plan_world_coord, 50)
        self._global_plan_world_coord = [(global_plan_world_coord[x][0], global_plan_world_coord[x][1]) for x in ds_ids]
        self._global_plan = [global_plan_gps[x] for x in ds_ids]
        # 历史兼容字段（某些旧逻辑会直接读取该变量）
        self._plan_gps_HACK = global_plan_gps
    
    def get_hero(self):
        """从当前世界演员列表中查找 role_name=hero 的自车对象并缓存。"""
        hero_actor = None
        from srunner.scenariomanager.carla_data_provider import CarlaDataProvider
        for actor in CarlaDataProvider.get_world().get_actors():
            if 'role_name' in actor.attributes and actor.attributes['role_name'] == 'hero':
                hero_actor = actor
                break
        self.hero_actor = hero_actor
    
    def get_metric_info(self):
        """提取 hero 车辆的关键运动学信息，返回用于评估/日志的字典。"""
        
        def vector2list(vector, rotation=False):
            # 统一把 CARLA 向量/旋转对象转换成纯 Python list，便于 JSON 序列化。
            if rotation:
                return [vector.roll, vector.pitch, vector.yaw]
            else:
                return [vector.x, vector.y, vector.z]

        output = {}
        output['acceleration'] = vector2list(self.hero_actor.get_acceleration())
        output['angular_velocity'] = vector2list(self.hero_actor.get_angular_velocity())
        output['forward_vector'] = vector2list(self.hero_actor.get_transform().get_forward_vector())
        output['right_vector'] = vector2list(self.hero_actor.get_transform().get_right_vector())
        output['location'] = vector2list(self.hero_actor.get_transform().location)
        output['rotation'] = vector2list(self.hero_actor.get_transform().rotation, rotation=True)
        return output