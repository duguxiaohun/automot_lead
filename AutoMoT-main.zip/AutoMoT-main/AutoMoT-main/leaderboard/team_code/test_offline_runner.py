#!/usr/bin/env python3
"""
测试离线 LEAD->AutoMoT bridge 的工作流程。

执行步骤：
1. 初始化 LeadOfflineMoTRunner
2. 加载 LEAD 数据集的一个 clip
3. 调用 run_clip 进行离线推理（包含KV缓存初始化）
"""

import sys
import os
import pathlib
import argparse

# 配置路径
_THIS_FILE = pathlib.Path(__file__).resolve()
_AUTOMOT_ROOT = _THIS_FILE.parents[2]
_AUTOMOT_PROJECT_ROOT = _THIS_FILE.parents[2] / "Automot"
_LEAD_ROOT = _AUTOMOT_ROOT.parent / "lead"

# 确保优先添加项目路径
if str(_AUTOMOT_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_AUTOMOT_PROJECT_ROOT))
if str(_AUTOMOT_ROOT) not in sys.path:
    sys.path.insert(0, str(_AUTOMOT_ROOT))
if str(_LEAD_ROOT) not in sys.path:
    sys.path.insert(0, str(_LEAD_ROOT))

# 改变到正确的工作目录
os.chdir(str(_AUTOMOT_ROOT))


def main():
    parser = argparse.ArgumentParser(description="Test offline LEAD->AutoMoT runner")
    parser.add_argument("--clip-index", type=int, default=0, help="LEAD video clip index")
    parser.add_argument("--anchor-stride", type=int, default=1, help="anchor stride")
    parser.add_argument("--device", type=str, default="cuda:0", help="device")
    args = parser.parse_args()
    
    print("=" * 60)
    print("OFFLINE LEAD -> AUTOMOT RUNNER TEST")
    print("=" * 60)
    
    # 1. 导入模块
    print("\n[Step 1] Importing modules...")
    try:
        from mot_lead_offline_runner import LeadOfflineMoTRunner, build_lead_video_dataset
        print("✓ Modules imported successfully")
    except Exception as e:
        print(f"✗ Import failed: {e}")
        return 1
    
    # 2. 初始化 Runner
    print("\n[Step 2] Initializing LeadOfflineMoTRunner...")
    try:
        runner = LeadOfflineMoTRunner(device=args.device)
        print("✓ Runner initialized")
        print(f"  - Device: {runner.device}")
        print(f"  - Model: {type(runner.automot).__name__}")
        print(f"  - BEV Encoder: {type(runner.bev_encoder).__name__}")
    except Exception as e:
        print(f"✗ Runner initialization failed: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    # 3. 加载数据集
    print("\n[Step 3] Loading LEAD dataset...")
    try:
        dataset = build_lead_video_dataset()
        print(f"✓ Dataset loaded (total clips: {len(dataset)})")
        
        clip = dataset[args.clip_index]
        print(f"✓ Clip #{args.clip_index} loaded")
        print(f"  - RGB shape: {clip['rgb'].shape}")
        print(f"  - Lidar shape: {clip['rasterized_lidar'].shape}")
    except Exception as e:
        print(f"✗ Dataset loading failed: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    # 4. 运行离线推理（这里会调用 kv_cache_fixed_inference）
    print(f"\n[Step 4] Running offline inference (anchor_stride={args.anchor_stride})...")
    print("         This will call kv_cache_fixed_inference internally...")
    try:
        outputs = runner.run_clip(clip, anchor_stride=args.anchor_stride)
        print(f"✓ Inference completed")
        print(f"  - Generated {len(outputs)} inference groups")
        
        # 打印前3个输出
        for i, out in enumerate(outputs[:3]):
            print(f"\n  [Group {i}]")
            print(f"    - Anchor t: {out['anchor_t']}")
            print(f"    - RGB indices (asc): {out['rgb_indices_asc']}")
            print(f"    - Text: {out['text'][:80] if out['text'] else 'None'}...")
            if out['traj'] is not None:
                print(f"    - Traj shape: {out['traj'].shape}")
            if out['route'] is not None:
                print(f"    - Route shape: {out['route'].shape}")
    except Exception as e:
        print(f"✗ Inference failed: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    print("\n" + "=" * 60)
    print("✓ ALL TESTS PASSED")
    print("=" * 60)
    return 0


if __name__ == "__main__":
    sys.exit(main())
