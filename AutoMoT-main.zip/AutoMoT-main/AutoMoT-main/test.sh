# # ===  清空旧失败结果 ===
# 禁用 core dump，避免评测异常时在当前目录生成 core.*。
ulimit -S -c 0 2>/dev/null || true

# EVAL_OUTPUT_DIR="${EVAL_OUTPUT_DIR:-$AUTOMOT_ROOT/outputs/leaderboard/v_2json_open}"
# LOG_OUTPUT_DIR="${LOG_OUTPUT_DIR:-$AUTOMOT_ROOT/outputs/leaderboard/logs}"
# mkdir -p "$EVAL_OUTPUT_DIR" "$LOG_OUTPUT_DIR"
# rm -f "$EVAL_OUTPUT_DIR"/*.json

cd $AUTOMOT_ROOT/leaderboard/scripts


# === 测试 ===
bash run_evaluation_route.sh 2>&1 | tee "$LOG_OUTPUT_DIR/full_test.log"
# SINGLE_TEST=1 bash run_evaluation_route.sh 2>&1 | tee "$LOG_OUTPUT_DIR/single_test.log"