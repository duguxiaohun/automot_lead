#!/usr/bin/env python3
"""
临时一次性脚本：下载 LEAD tfv6_resnet34 ckpt + config,
提取 backbone.* 子集另存,顺带 patch mot_lead_offline_runner.py 里
LEAD_BEV_CKPT_PATH 常量指向提取后的 backbone-only ckpt。

⚠ 本脚本不入 git, 不进 .md, 跑一次即可丢弃。

文件位置约定:
    /home/cruser1/lda/AutoMoT/download_lead_bev_ckpt.py

运行方式:
    cd /home/cruser1/lda/AutoMoT
    python download_lead_bev_ckpt.py

依赖:
    - wget (系统命令)
    - torch (用于读取 .pth + 过滤 state_dict)
"""

from __future__ import annotations

import pathlib
import subprocess
import sys

import torch


# ============== 路径配置(按用户服务器实际情况)==============
AUTOMOT_ROOT = pathlib.Path("/home/cruser1/lda/AutoMoT")

# HuggingFace 资源 URL (LEAD 官方 tfv6_resnet34, seed 0)
HF_BASE = "https://huggingface.co/ln2697/tfv6/resolve/main/tfv6_resnet34"
HF_CONFIG_URL = f"{HF_BASE}/config.json"
HF_CKPT_URL = f"{HF_BASE}/model_0030_0.pth"

# 本地保存路径:统一放在 AutoMoT/checkpoints/ 下,与 AutoMoT/checkpoints/AutoMoT/ 同级
CKPT_DIR = AUTOMOT_ROOT / "checkpoints" / "tfv6_resnet34"
FULL_CKPT_PATH = CKPT_DIR / "model_0030_0.pth"             # 完整 ckpt,提取完后会被删除
CONFIG_PATH = CKPT_DIR / "config.json"                     # 保留供日后对照 LeadBevConfig

# 提取出的 backbone-only 子集(供 LeadBEVEncoder 加载;前缀已剥,内部 key 形如
# image_encoder.* / lidar_encoder.* / transformers.* / c5_conv.* / up_conv*.* 等)
BACKBONE_ONLY_CKPT = CKPT_DIR / "model_0030_0_backbone_only.pth"

# 需要 patch 的 runner 文件 + 目标常量
RUNNER_PATH = AUTOMOT_ROOT / "leaderboard" / "team_code" / "mot_lead_offline_runner.py"


def step1_download() -> None:
    """下载 config + full ckpt(已存在则跳过)。"""
    CKPT_DIR.mkdir(parents=True, exist_ok=True)

    if CONFIG_PATH.exists():
        print(f"[1/4] config.json 已存在,跳过: {CONFIG_PATH}")
    else:
        print(f"[1/4] 下载 config.json → {CONFIG_PATH}")
        subprocess.check_call(["wget", "-q", HF_CONFIG_URL, "-O", str(CONFIG_PATH)])

    if FULL_CKPT_PATH.exists():
        print(f"[2/4] model_0030_0.pth 已存在,跳过: {FULL_CKPT_PATH}")
    else:
        print(f"[2/4] 下载 model_0030_0.pth → {FULL_CKPT_PATH}")
        subprocess.check_call(["wget", "-q", HF_CKPT_URL, "-O", str(FULL_CKPT_PATH)])


def step2_extract_backbone() -> None:
    """从 full ckpt 里抽 backbone.* 前缀子集另存(剥前缀,与
    LeadBEVEncoder._load_lead_weights 加载逻辑保持一致)。"""
    print(f"[3/4] 读取完整 ckpt: {FULL_CKPT_PATH}")
    full_sd = torch.load(str(FULL_CKPT_PATH), map_location="cpu")
    if isinstance(full_sd, dict) and "model" in full_sd and isinstance(full_sd["model"], dict):
        full_sd = full_sd["model"]

    backbone_sd = {
        k[len("backbone."):]: v
        for k, v in full_sd.items()
        if k.startswith("backbone.")
    }
    non_backbone_keys = [k for k in full_sd if not k.startswith("backbone.")]

    print(f"        backbone.* 权重数: {len(backbone_sd)}")
    print(f"        非 backbone.* 权重数: {len(non_backbone_keys)} (将被丢弃)")
    if non_backbone_keys:
        sample = non_backbone_keys[:5]
        print(f"        非 backbone 前 5 个 key 样例: {sample}")

    if not backbone_sd:
        print("        ⚠ 没找到任何 backbone.* 权重! 检查 ckpt 是否符合预期结构。")
        sys.exit(2)

    torch.save(backbone_sd, str(BACKBONE_ONLY_CKPT))
    size_mb = BACKBONE_ONLY_CKPT.stat().st_size / 1024 / 1024
    print(f"        已保存 backbone-only ckpt: {BACKBONE_ONLY_CKPT} ({size_mb:.1f} MB)")

    # 删除完整 ckpt(只保留 backbone-only + config.json)
    if FULL_CKPT_PATH.exists():
        full_size_mb = FULL_CKPT_PATH.stat().st_size / 1024 / 1024
        FULL_CKPT_PATH.unlink()
        print(f"        已删除完整 ckpt: {FULL_CKPT_PATH} ({full_size_mb:.1f} MB 已释放)")


def step3_patch_runner() -> None:
    """把 runner 里 LEAD_BEV_CKPT_PATH 改成提取后 backbone-only ckpt 的绝对路径。

    幂等:若已是目标值则跳过;若与 placeholder None 不匹配也跳过(避免误改)。
    """
    print(f"[4/4] Patch {RUNNER_PATH}")
    if not RUNNER_PATH.exists():
        print(f"        ⚠ runner 路径不存在,跳过: {RUNNER_PATH}")
        return

    text = RUNNER_PATH.read_text(encoding="utf-8")
    target = str(BACKBONE_ONLY_CKPT)
    new_line = f'LEAD_BEV_CKPT_PATH: str | None = "{target}"'

    # 1. 已经是目标路径 -> 跳过
    if new_line in text:
        print(f"        ✓ LEAD_BEV_CKPT_PATH 已是目标路径,无需改动")
        return

    # 2. 仍是 placeholder None -> 替换
    placeholder = "LEAD_BEV_CKPT_PATH: str | None = None"
    if placeholder in text:
        text = text.replace(placeholder, new_line, 1)
        RUNNER_PATH.write_text(text, encoding="utf-8")
        print(f"        ✓ 已 patch: {new_line}")
        return

    # 3. 其它情况(可能用户手动改过) -> 提示但不强改
    print(f"        ⚠ 未找到 placeholder None,也未找到目标行;LEAD_BEV_CKPT_PATH 可能已被手动改过")
    print(f"        请手动确认 runner 顶部 LEAD_BEV_CKPT_PATH 是否指向: {target}")


def main() -> None:
    print(f"AUTOMOT_ROOT = {AUTOMOT_ROOT}")
    print(f"BACKBONE_ONLY_CKPT 目标路径 = {BACKBONE_ONLY_CKPT}\n")

    step1_download()
    step2_extract_backbone()
    step3_patch_runner()

    print("\n✓ 全部完成。下一步:")
    print(f"  cd {AUTOMOT_ROOT}")
    print("  python leaderboard/team_code/mot_lead_offline_runner.py --route-dir <某个 LEAD route>")
    print("  期望: LeadBEVEncoder 打印 'loaded ... missing=N, unexpected=0'")


if __name__ == "__main__":
    main()
