#!/bin/bash

set -u

# 禁用 core dump，避免 CarlaUE4/Python 崩溃时写出 core.* 大文件。
ulimit -S -c 0 2>/dev/null || true

# ==============================
# CARLA start config
# ==============================

export CARLA_ROOT=/datashare/CARLA_0915

# 设置初始默认值
CARLA_PORT=5000
USER_GPU=""

# 解析命令行参数
while getopts "p:g:h" opt; do
  case $opt in
    p) CARLA_PORT="$OPTARG" ;;
    g) USER_GPU="$OPTARG" ;;
    h)
      echo "用法: $0 [-p 端口号] [-g GPU_ID]"
      echo "示例: $0 -p 6000 -g 1"
      echo "如果不输入参数，将默认使用端口 5000 并自动寻找空闲 GPU。"
      exit 0
      ;;
    \?)
      echo "无效选项 -$OPTARG" >&2
      exit 1
      ;;
  esac
done

# 动态计算其他端口
STREAMING_PORT=$((CARLA_PORT + 1))
TM_PORT=$((CARLA_PORT + 8000))

# 确定 GPU_ID 的逻辑
if [ -n "$USER_GPU" ]; then
    # 如果用户主动输入了 GPU 参数，则使用用户指定的 GPU
    GPU_ID="$USER_GPU"
    echo ">>> 使用用户指定的 GPU: $GPU_ID"
else
    # 否则执行默认逻辑：自动搜索显存占用最少的 GPU
    echo ">>> 未手动指定 GPU，正在自动搜索显存占用最少的 GPU..."
    if command -v nvidia-smi >/dev/null 2>&1; then
        # 获取 "索引, 已用显存" 列表，按显存升序排序，并提取第一行的 GPU 索引
        GPU_ID=$(nvidia-smi --query-gpu=index,memory.used --format=csv,noheader,nounits | sort -t ',' -k2 -n | awk -F ',' 'NR==1 {print $1}')
        # 去除可能存在的空格
        GPU_ID=$(echo "$GPU_ID" | tr -d ' ')
    else
        echo "警告: 未找到 nvidia-smi 命令，默认使用 GPU 0"
        GPU_ID=0
    fi
fi

LOG_FILE=/tmp/carla_${CARLA_PORT}.log

echo "========== Start CARLA =========="
echo "CARLA_ROOT     : $CARLA_ROOT"
echo "CARLA_PORT     : $CARLA_PORT"
echo "STREAMING_PORT : $STREAMING_PORT"
echo "TM_PORT        : $TM_PORT"
echo "GPU_ID         : $GPU_ID"
echo "LOG_FILE       : $LOG_FILE"
echo "================================="

if [ ! -f "$CARLA_ROOT/CarlaUE4.sh" ]; then
    echo "ERROR: Cannot find $CARLA_ROOT/CarlaUE4.sh"
    exit 1
fi

echo ">>> Killing old CARLA processes on ports $CARLA_PORT, $STREAMING_PORT and $TM_PORT..."

if command -v lsof >/dev/null 2>&1; then
    lsof -ti:$CARLA_PORT | xargs -r kill -9 2>/dev/null || true
    lsof -ti:$TM_PORT | xargs -r kill -9 2>/dev/null || true
    lsof -ti:$STREAMING_PORT | xargs -r kill -9 2>/dev/null || true
else
    fuser -k -n tcp $CARLA_PORT >/dev/null 2>&1 || true
    fuser -k -n tcp $TM_PORT >/dev/null 2>&1 || true
    fuser -k -n tcp $STREAMING_PORT >/dev/null 2>&1 || true
fi

pkill -9 -f "CarlaUE4.*-carla-rpc-port=$CARLA_PORT" 2>/dev/null || true
pkill -9 -f "CarlaUE4.*-traffic-manager-port=$TM_PORT" 2>/dev/null || true

sleep 2

echo ">>> Launching CARLA on GPU $GPU_ID..."

cd "$CARLA_ROOT" || exit 1

CUDA_VISIBLE_DEVICES=$GPU_ID "$CARLA_ROOT/CarlaUE4.sh" \
    -RenderOffScreen \
    -nosound \
    -carla-rpc-port=$CARLA_PORT \
    -traffic-manager-port=$TM_PORT \
    -carla-streaming-port=$STREAMING_PORT \
    -quality-level=Low \
    -resx=800 \
    -resy=600 \
    -graphicsadapter=0 \
    > "$LOG_FILE" 2>&1 &

CARLA_SHELL_PID=$!

sleep 3

echo ">>> CARLA start command issued."
echo "Shell PID: $CARLA_SHELL_PID"
echo "Check:"
echo "  lsof -i:$CARLA_PORT"
echo "  tail -f $LOG_FILE"