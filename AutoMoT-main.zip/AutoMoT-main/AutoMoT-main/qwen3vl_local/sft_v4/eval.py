﻿"""SFT v4 离线评测。

评测口径：
1. 只跑学生模型，不使用 teacher。
2. 不做 Phase B GT 强制注入，memory 全程由学生自更新。
3. 默认评测区间与训练一致：[f1-delta, f3]。
4. 输出关键指标：road_structure_acc、step2_fire_rate、scene_acc、scene_recovery_steps、
   scene_stick_rate、scene_flip_rate、step3_trigger_rate、status/subgoal 条件准确率、all_acc。
"""

from __future__ import annotations

import argparse
import json
import os
import pathlib
import subprocess
import sys
from collections import defaultdict
from typing import Any, Dict, List, Optional, Tuple

_THIS_FILE = pathlib.Path(__file__).resolve()
_AUTOMOT_ROOT = _THIS_FILE.parents[2]
_PROJECT_ROOT = _THIS_FILE.parents[3]
for _p in (str(_AUTOMOT_ROOT), str(_PROJECT_ROOT)):
    if _p not in sys.path:
        sys.path.insert(0, _p)


def _cli_value(name: str) -> Optional[str]:
    """在 import torch 前读取命令行参数，用于早期 GPU 选址。"""

    prefix = name + "="
    args = sys.argv[1:]
    for i, item in enumerate(args):
        if item == name and i + 1 < len(args):
            return args[i + 1]
        if item.startswith(prefix):
            return item[len(prefix):]
    return None


def _normalize_gpu_ids(value: str) -> str:
    """规范化逗号分隔的 GPU id 列表。"""

    return ",".join(part.strip() for part in value.split(",") if part.strip())


def _pick_idle_gpus(n: int = 1) -> str:
    """用 nvidia-smi 选择最空闲 GPU；CPU 机器或 nvidia-smi 不可用时返回空串。"""

    try:
        out = subprocess.check_output(
            [
                "nvidia-smi",
                "--query-gpu=index,memory.used,utilization.gpu",
                "--format=csv,noheader,nounits",
            ],
            text=True,
            stderr=subprocess.DEVNULL,
        )
    except Exception:
        return ""
    rows = []
    for line in out.splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) < 3:
            continue
        try:
            rows.append((int(parts[1]), int(parts[2]), parts[0]))
        except ValueError:
            continue
    rows.sort(key=lambda x: (x[0], x[1], int(x[2]) if str(x[2]).isdigit() else 9999))
    return ",".join(row[2] for row in rows[:n])


def _maybe_set_idle_gpu_mask() -> None:
    """在 torch/transformers 初始化 CUDA 前设置 CUDA_VISIBLE_DEVICES。"""

    device = _cli_value("--device")
    if device and device.lower() not in ("", "auto"):
        return
    pinned = _normalize_gpu_ids(os.environ.get("GPU_IDS", ""))
    if pinned:
        os.environ["CUDA_VISIBLE_DEVICES"] = pinned
        print(f"[gpu] using GPU_IDS={pinned}")
        return
    selected = _pick_idle_gpus(1)
    if selected:
        os.environ["CUDA_VISIBLE_DEVICES"] = selected
        print(f"[gpu] auto CUDA_VISIBLE_DEVICES={selected}")


os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
# 必须在 import torch / engine / train 前选卡：CUDA 可见列表一旦被 torch 初始化，
# 后续再改 CUDA_VISIBLE_DEVICES 就不能可靠覆盖继承来的 mask。
_maybe_set_idle_gpu_mask()

from PIL import Image
import torch

from qwen3vl_local.sft_v4.train import (
    EpisodeDataset,
    EpisodeRow,
    _analysis_before_labels,
    _build_messages_with_images,
    _build_rgb_paths,
    _gt_status_subgoal,
    _is_phase_a,
    _load_goal_xy,
    _load_images,
    _prefetch_goal_xy_for_next_frame,
)
from qwen3vl_local.sft_v4.prompts import (
    TEACHER_MAX_NEW_TOKENS_STEP1,
    TEACHER_MAX_NEW_TOKENS_STEP2,
    TEACHER_MAX_NEW_TOKENS_STEP3,
    build_step1_teacher_prompt,
    build_step1_user_prompt,
    build_step2_student_prompt,
    build_step2_teacher_prompt,
    build_step3_student_prompt,
    build_step3_teacher_prompt,
    get_road_structure,
    get_step_system_prompt,
    init_memory,
    parse_output,
    should_trigger_step2,
    should_trigger_step3,
    update_memory_after_step1,
    update_memory_after_step2,
    update_memory_after_step3,
    validate_event,
    validate_road_structure,
    validate_scene,
)

from qwen3vl_local.engine import LocalQwen3VLInstructEngine
from qwen3vl_local.mrope_utils import qwen3vl_incremental_forward


def _simple_bleu(candidate: str, reference: str, max_n: int = 2) -> float:
    """无第三方依赖的轻量 BLEU，用于可选 teacher 分析对齐指标。

    这里只做诊断，不作为主指标；max_n 默认 2，能粗略反映学生分析是否跟 teacher
    hindsight 分析使用相似证据词，而不会引入 nltk/sacrebleu 依赖。
    """

    import math
    import re
    from collections import Counter

    cand = re.findall(r"\w+", (candidate or "").lower())
    ref = re.findall(r"\w+", (reference or "").lower())
    if not cand or not ref:
        return 0.0
    precisions: List[float] = []
    for n in range(1, max_n + 1):
        if len(cand) < n:
            precisions.append(0.0)
            continue
        cand_counts = Counter(tuple(cand[i : i + n]) for i in range(len(cand) - n + 1))
        ref_counts = Counter(tuple(ref[i : i + n]) for i in range(len(ref) - n + 1))
        overlap = sum(min(count, ref_counts[gram]) for gram, count in cand_counts.items())
        precisions.append((overlap + 1.0) / (sum(cand_counts.values()) + 1.0))
    brevity = 1.0 if len(cand) > len(ref) else math.exp(1.0 - len(ref) / max(len(cand), 1))
    return float(brevity * math.exp(sum(math.log(max(p, 1e-8)) for p in precisions) / max_n))


def _generate(engine: LocalQwen3VLInstructEngine, messages: List[Dict[str, Any]], images: List[Image.Image], max_new_tokens: int) -> str:
    """生成 step1 文本，并在 engine._last_decode_state 中留下 KV cache。

    eval/probe 走 `LocalQwen3VLInstructEngine` 的真实自由生成路径；后续 step2/step3
    会从这个 cache 继续追加 user turn，模拟训练时的三步 OPD 对话。
    """

    system = messages[0]["content"]
    # 将 messages 扁平化到 user prompt（保持与 train 一致的 turn 结构）。
    prompt_lines: List[str] = []
    for m in messages[1:]:
        role = m.get("role")
        content = m.get("content")
        if isinstance(content, list):
            # 首个 user 带图 + 文本
            text_parts = [x.get("text", "") for x in content if isinstance(x, dict) and x.get("type") == "text"]
            prompt_lines.append("\n".join(text_parts))
        else:
            prompt_lines.append(f"[{role}]\n{content}")
    user_prompt = "\n\n".join([x for x in prompt_lines if x])
    old_max = getattr(engine, "max_gen_tokens", None)
    if old_max is not None:
        engine.max_gen_tokens = int(max_new_tokens)
    try:
        txt, _ = engine.generate(system, user_prompt, images)
    finally:
        if old_max is not None:
            engine.max_gen_tokens = old_max
    return txt.strip()


def _generate_teacher(engine: LocalQwen3VLInstructEngine, messages: List[Dict[str, Any]], images: List[Image.Image], max_new_tokens: int) -> str:
    """生成 teacher 文本并立即释放 teacher KV state。

    Teacher step1/2/3 都是独立专家问答，不复用上一轮 KV；如果保留
    ``_last_decode_state``，下一次 full prefill 会和上一轮 teacher KV 同时常驻显存，
    `--with-teacher` 小样本 probe/eval 很容易 OOM。
    """

    try:
        return _generate(engine, messages, images, max_new_tokens)
    finally:
        engine._last_decode_state = None


def _render_user_suffix(engine: LocalQwen3VLInstructEngine, user_prompt: str) -> str:
    """把后续 user turn 渲染为 Qwen chat template 片段。"""

    suffix = engine.processor.apply_chat_template(
        [{"role": "user", "content": user_prompt}],
        tokenize=False,
        add_generation_prompt=True,
    )
    return suffix if suffix.startswith("\n") else "\n" + suffix


def _generate_next_with_kv(
    engine: LocalQwen3VLInstructEngine,
    user_prompt: str,
    *,
    max_new_tokens: int,
) -> str:
    """从上一轮 decode 后的 KV cache 继续追加 user turn 并生成 assistant 文本。

    这个函数是 eval/probe 的 KV 复用核心：不重新喂图，只把 step2/step3 的文本
    user turn 接到已有 cache 后继续 decode。
    """

    state = getattr(engine, "_last_decode_state", None)
    if not state:
        raise RuntimeError("missing previous KV state; call step1 generate first")

    prefix_ids = state.get("cache_input_ids", state["decoded_input_ids"])
    prefix_len = int(prefix_ids.shape[1])
    decoded_ids = state["decoded_input_ids"].to(prefix_ids.device)
    pending_generated_ids = decoded_ids[:, prefix_len:]
    suffix_text = _render_user_suffix(engine, user_prompt)
    if pending_generated_ids.shape[1] == 0:
        suffix_text = "<|im_end|>" + suffix_text
    suffix_ids = engine.processor.tokenizer(
        suffix_text,
        add_special_tokens=False,
        return_tensors="pt",
    )["input_ids"].to(prefix_ids.device)
    if pending_generated_ids.shape[1] > 0:
        suffix_ids = torch.cat([pending_generated_ids, suffix_ids], dim=1)

    old_attention = state["attention_mask"]
    if old_attention is None:
        old_attention = torch.ones_like(prefix_ids, device=prefix_ids.device)
    attention_mask = torch.cat(
        [old_attention, torch.ones_like(suffix_ids, device=old_attention.device)],
        dim=1,
    )
    decoded_input_ids = torch.cat([prefix_ids, suffix_ids], dim=1)
    # 与 sft_v4/train 同一处修复：不走 prepare_inputs_for_generation（PEFT 会裁掉
    # cache_position 导致 mrope 位置塌成 0），改用本地 qwen3vl_incremental_forward，
    # 用本条 KV 状态自带的 rope_deltas 复算 mrope position_ids 后再 forward。
    with torch.inference_mode():
        outputs = qwen3vl_incremental_forward(
            engine.model,
            feed_ids=suffix_ids,
            attention_mask=attention_mask,
            past_key_values=state["past_key_values"],
            prefix_len=prefix_len,
            rope_deltas=state.get("rope_deltas"),
        )

    trace = type("_Trace", (), {
        "prefill_cache_summary": {},
        "final_cache_summary": {},
        "decode_steps": [],
        "prefill_cache_file": None,
        "final_cache_file": None,
        "system_prompt_cache_enabled": False,
        "system_prompt_cache_used": False,
        "system_prompt_cache_note": None,
        "system_prompt_cache_summary": {},
    })()
    old_max = getattr(engine, "max_gen_tokens", None)
    if old_max is not None:
        engine.max_gen_tokens = int(max_new_tokens)
    try:
        with torch.inference_mode():
            new_ids = engine.decode(
                {"input_ids": decoded_input_ids, "attention_mask": attention_mask},
                outputs,
                trace,
            )
    finally:
        if old_max is not None:
            engine.max_gen_tokens = old_max
    return engine.processor.batch_decode(new_ids, skip_special_tokens=True)[0].strip()


def parse_args() -> argparse.Namespace:
    """解析离线 eval 参数。"""

    p = argparse.ArgumentParser(description="Evaluate SFT v4 sequence LoRA")
    p.add_argument("--jsonl", type=str, default="checkpoints/sft_v4_data/val.jsonl")
    p.add_argument("--model-dir", type=str, default="checkpoints/Qwen3-VL-4B-Instruct")
    p.add_argument("--lora-dir", type=str, default="checkpoints/sft_v4_lora/latest/final")
    p.add_argument("--save-root", type=str, default="checkpoints/sft_v4_lora/latest")
    p.add_argument("--device", type=str, default="auto")
    p.add_argument("--max-episodes", type=int, default=0)
    p.add_argument("--max-gen-tokens", type=int, default=80)
    p.add_argument("--repetition-penalty", type=float, default=1.05)
    p.add_argument("--merge-lora", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--full-range", action="store_true",
                   help="诊断模式：评估 [anchor0, anchor4]，默认只评估训练窗口 [anchor1-delta, anchor3]")
    p.add_argument("--with-teacher-ref", action="store_true",
                   help="可选：额外加载 base Qwen teacher，计算 analysis_bleu_vs_teacher")
    return p.parse_args()


def main() -> None:
    """SFT v4 离线自由生成评估入口。

    与训练不同，eval 默认不做 Phase B 的 GT scene 强制覆盖，memory 全程由学生自由
    输出更新；这样才能真实观察 road_structure / scene recovery、stick、flip 和
    step2/step3 trigger。
    """

    args = parse_args()

    ds = EpisodeDataset(pathlib.Path(args.jsonl))
    episodes = list(ds.rows)
    if args.max_episodes > 0:
        episodes = episodes[: args.max_episodes]

    save_root = pathlib.Path(args.save_root)
    out_dir = save_root / "eval_v4"
    out_dir.mkdir(parents=True, exist_ok=True)

    engine = LocalQwen3VLInstructEngine(
        pathlib.Path(args.model_dir),
        device=args.device,
        max_gen_tokens=args.max_gen_tokens,
        temperature=0.0,
        do_sample=False,
        repetition_penalty=args.repetition_penalty,
    )
    engine.load()
    if args.lora_dir:
        engine.attach_lora_adapter(args.lora_dir, merge=args.merge_lora)

    teacher_engine = None
    if args.with_teacher_ref:
        # teacher-ref 是可选重路径：额外加载一份 base Qwen，只计算分析文本 BLEU。
        teacher_engine = LocalQwen3VLInstructEngine(
            pathlib.Path(args.model_dir),
            device=args.device,
            max_gen_tokens=args.max_gen_tokens,
            temperature=0.0,
            do_sample=False,
            repetition_penalty=args.repetition_penalty,
        )
        teacher_engine.load()

    metrics = defaultdict(float)
    per_episode: List[Dict[str, Any]] = []
    phase_keys = ("phase_a", "phase_b")

    for ep in episodes:
        run_dir = pathlib.Path(ep.run_dir)
        eval_start = int(ep.anchors[0]) if args.full_range else int(ep.frame_start)
        eval_end = int(ep.anchors[4]) if args.full_range else int(ep.frame_end)
        gx, gy = _load_goal_xy(run_dir, eval_start)
        gt_road_structure = get_road_structure(ep.gt_scene)
        memory = init_memory(
            run_id=ep.run_id,
            sub_scenario_id=f"{ep.run_id}:{ep.anchors[1]}",
            ego_to_goal_x=gx,
            ego_to_goal_y=gy,
            gt_scene=ep.gt_scene,
        )

        frame_total = 0
        road_structure_correct = 0
        step2_total = 0
        scene_correct = 0
        step3_total = 0
        status_correct = 0
        subgoal_correct = 0
        all_correct = 0
        rs_flip = 0
        scene_flip = 0
        scene_stick_ok = 0
        scene_stick_total = 0
        invalid_road_structure = 0
        invalid_scene = 0
        invalid_status = 0
        invalid_subgoal = 0
        first_recover: Optional[int] = None
        phase_first_frame: Dict[str, Optional[int]] = {pk: None for pk in phase_keys}
        phase_first_recover: Dict[str, Optional[int]] = {pk: None for pk in phase_keys}
        prev_scene_ok: Optional[bool] = None

        for frame in range(eval_start, eval_end + 1):
            phase = "phase_a" if _is_phase_a(ep, frame) else "phase_b"
            if phase_first_frame[phase] is None:
                phase_first_frame[phase] = frame
            image_paths = _build_rgb_paths(run_dir, frame)
            try:
                images = _load_images(image_paths)
            except Exception:
                _prefetch_goal_xy_for_next_frame(memory, run_dir, frame + 1, eval_end)
                continue

            gt_status, gt_subgoal = _gt_status_subgoal(ep, frame)

            step1_user = build_step1_user_prompt(len(images), memory=memory)
            step1_msgs = _build_messages_with_images(user_text=step1_user, images=images, system_prompt=get_step_system_prompt("STEP1"))
            teacher_step1_text = ""
            if teacher_engine is not None:
                teacher_step1_user = build_step1_teacher_prompt(memory, gt_road_structure)
                teacher_step1_msgs = _build_messages_with_images(user_text=teacher_step1_user, images=images, system_prompt=get_step_system_prompt("STEP1"))
                teacher_step1_text = _generate_teacher(
                    teacher_engine,
                    teacher_step1_msgs,
                    images,
                    max_new_tokens=TEACHER_MAX_NEW_TOKENS_STEP1,
                )
            step1_text = _generate(engine, step1_msgs, images, max_new_tokens=TEACHER_MAX_NEW_TOKENS_STEP1)
            if teacher_engine is not None:
                metrics["analysis_bleu_sum"] += _simple_bleu(
                    _analysis_before_labels(step1_text),
                    _analysis_before_labels(teacher_step1_text),
                )
                metrics["analysis_bleu_count"] += 1
            p1 = parse_output(step1_text)
            if not validate_road_structure(p1.get("road_structure")):
                invalid_road_structure += 1

            old_rs = memory.road_structure
            memory = update_memory_after_step1(memory, student_road_structure=p1.get("road_structure"))
            if memory.road_structure != old_rs:
                rs_flip += 1
            rs_ok = memory.road_structure == gt_road_structure
            if rs_ok:
                road_structure_correct += 1

            step2_fire = should_trigger_step2(
                memory_road_structure_before_step1=old_rs,
                memory_road_structure_after_step1=memory.road_structure,
                gt_road_structure=gt_road_structure,
            )

            teacher_step2_text = ""
            step2_text = ""
            scene_ok = False
            if step2_fire:
                step2_total += 1
                if teacher_engine is not None:
                    teacher_step2_user = build_step2_teacher_prompt(memory, gt_road_structure, ep.gt_scene)
                    teacher_step2_msgs = _build_messages_with_images(user_text=teacher_step2_user, images=images, system_prompt=get_step_system_prompt("STEP2"))
                    teacher_step2_text = _generate_teacher(
                        teacher_engine,
                        teacher_step2_msgs,
                        images,
                        max_new_tokens=TEACHER_MAX_NEW_TOKENS_STEP2,
                    )
                step2_user = build_step2_student_prompt(memory)
                step2_text = _generate_next_with_kv(engine, step2_user, max_new_tokens=TEACHER_MAX_NEW_TOKENS_STEP2)
                if teacher_engine is not None:
                    metrics["analysis_bleu_sum"] += _simple_bleu(
                        _analysis_before_labels(step2_text),
                        _analysis_before_labels(teacher_step2_text),
                    )
                    metrics["analysis_bleu_count"] += 1
                p2 = parse_output(step2_text)
                if not validate_scene(p2.get("scene")):
                    invalid_scene += 1

                old_scene = memory.scene
                memory = update_memory_after_step2(memory, student_scene=p2.get("scene"))
                if memory.scene != old_scene:
                    scene_flip += 1

                scene_ok = should_trigger_step3(
                    memory_scene_before_step2=old_scene,
                    memory_scene_after_step2=memory.scene,
                    gt_scene=ep.gt_scene,
                )
            if scene_ok:
                scene_correct += 1
                if first_recover is None:
                    first_recover = frame - ep.frame_start
                if phase_first_recover[phase] is None:
                    # Phase 分项 recovery 从该 phase 的第一帧算起，用来观察 Phase A 末尾
                    # 是否已经锁定 GT，以及 Phase B 区间是否能保持。
                    phase_start = phase_first_frame[phase] if phase_first_frame[phase] is not None else frame
                    phase_first_recover[phase] = frame - phase_start

            # stick 统计：上一帧 scene 已正确时，本帧是否保持正确。
            if prev_scene_ok is True:
                scene_stick_total += 1
                if scene_ok:
                    scene_stick_ok += 1

            status_ok = False
            subgoal_ok = False
            if scene_ok:
                # 只有 scene 正确时才进入 step3；这与训练触发条件一致。
                step3_total += 1
                teacher_step3_text = ""
                if teacher_engine is not None:
                    teacher_step3_user = build_step3_teacher_prompt(
                        memory,
                        gt_road_structure,
                        ep.gt_scene,
                        gt_status,
                        gt_subgoal,
                    )
                    teacher_step3_msgs = _build_messages_with_images(user_text=teacher_step3_user, images=images, system_prompt=get_step_system_prompt("STEP3"))
                    teacher_step3_text = _generate_teacher(
                        teacher_engine,
                        teacher_step3_msgs,
                        images,
                        max_new_tokens=TEACHER_MAX_NEW_TOKENS_STEP3,
                    )
                step3_user = build_step3_student_prompt(memory)
                step3_text = _generate_next_with_kv(engine, step3_user, max_new_tokens=TEACHER_MAX_NEW_TOKENS_STEP3)
                if teacher_engine is not None:
                    metrics["analysis_bleu_sum"] += _simple_bleu(
                        _analysis_before_labels(step3_text),
                        _analysis_before_labels(teacher_step3_text),
                    )
                    metrics["analysis_bleu_count"] += 1
                p3 = parse_output(step3_text)

                pred_status = p3.get("status") if validate_event(memory.scene, p3.get("status")) else None
                pred_subgoal = p3.get("subgoal") if validate_event(memory.scene, p3.get("subgoal")) else None
                invalid_status += int(pred_status is None)
                invalid_subgoal += int(pred_subgoal is None)
                memory = update_memory_after_step3(memory, student_status=pred_status, student_subgoal=pred_subgoal)

                status_ok = memory.status == gt_status
                subgoal_ok = memory.subgoal == gt_subgoal
                if status_ok:
                    status_correct += 1
                if subgoal_ok:
                    subgoal_correct += 1

            if scene_ok and status_ok and subgoal_ok:
                all_correct += 1

            frame_total += 1
            prev_scene_ok = scene_ok

            metrics[f"{phase}/frames"] += 1
            metrics[f"{phase}/road_structure_correct"] += 1 if rs_ok else 0
            metrics[f"{phase}/step2_total"] += 1 if step2_fire else 0
            metrics[f"{phase}/scene_correct"] += 1 if scene_ok else 0
            metrics[f"{phase}/step3_total"] += 1 if scene_ok else 0
            metrics[f"{phase}/status_correct"] += 1 if status_ok else 0
            metrics[f"{phase}/subgoal_correct"] += 1 if subgoal_ok else 0
            metrics[f"{phase}/all_correct"] += 1 if (scene_ok and status_ok and subgoal_ok) else 0
            _prefetch_goal_xy_for_next_frame(memory, run_dir, frame + 1, eval_end)

        epi = {
            "run_id": ep.run_id,
            "scenario": ep.scenario,
            "raw_gt_scene": ep.raw_gt_scene,
            "gt_scene": ep.gt_scene,
            "frames": frame_total,
            "road_structure_acc": road_structure_correct / max(frame_total, 1),
            "step2_fire_rate": step2_total / max(frame_total, 1),
            "scene_acc": scene_correct / max(frame_total, 1),
            "scene_recovery_steps": first_recover if first_recover is not None else -1,
            "scene_stick_rate": scene_stick_ok / max(scene_stick_total, 1),
            "road_structure_flip_rate": rs_flip / max(frame_total, 1),
            "scene_flip_rate": scene_flip / max(frame_total, 1),
            "step3_trigger_rate": step3_total / max(frame_total, 1),
            "status_acc_given_correct_scene": status_correct / max(step3_total, 1),
            "subgoal_acc_given_correct_scene": subgoal_correct / max(step3_total, 1),
            "all_acc": all_correct / max(frame_total, 1),
            "invalid_road_structure_rate": invalid_road_structure / max(frame_total, 1),
            "invalid_scene_rate": invalid_scene / max(frame_total, 1),
            "invalid_status_for_pred_scene_rate": invalid_status / max(step3_total, 1),
            "invalid_subgoal_for_pred_scene_rate": invalid_subgoal / max(step3_total, 1),
        }
        per_episode.append(epi)

        metrics["episodes"] += 1
        metrics["frames"] += frame_total
        metrics["road_structure_acc_sum"] += epi["road_structure_acc"]
        metrics["step2_sum"] += epi["step2_fire_rate"]
        metrics["scene_acc_sum"] += epi["scene_acc"]
        metrics["scene_stick_sum"] += epi["scene_stick_rate"]
        metrics["road_structure_flip_sum"] += epi["road_structure_flip_rate"]
        metrics["scene_flip_sum"] += epi["scene_flip_rate"]
        metrics["step3_sum"] += epi["step3_trigger_rate"]
        metrics["status_sum"] += epi["status_acc_given_correct_scene"]
        metrics["subgoal_sum"] += epi["subgoal_acc_given_correct_scene"]
        metrics["all_sum"] += epi["all_acc"]
        metrics["invalid_road_structure_sum"] += epi["invalid_road_structure_rate"]
        metrics["invalid_scene_sum"] += epi["invalid_scene_rate"]
        metrics["invalid_status_sum"] += epi["invalid_status_for_pred_scene_rate"]
        metrics["invalid_subgoal_sum"] += epi["invalid_subgoal_for_pred_scene_rate"]
        if epi["scene_recovery_steps"] >= 0:
            metrics["scene_recover_sum"] += epi["scene_recovery_steps"]
            metrics["scene_recover_count"] += 1
        for pk in phase_keys:
            rec = phase_first_recover[pk]
            if rec is not None:
                metrics[f"{pk}/scene_recover_sum"] += rec
                metrics[f"{pk}/scene_recover_count"] += 1

    n_epi = max(int(metrics["episodes"]), 1)
    summary = {
        "episodes": int(metrics["episodes"]),
        "frames": int(metrics["frames"]),
        "road_structure_acc": metrics["road_structure_acc_sum"] / n_epi,
        "step2_fire_rate": metrics["step2_sum"] / n_epi,
        "scene_acc_per_step": metrics["scene_acc_sum"] / n_epi,
        "scene_stick_rate": metrics["scene_stick_sum"] / n_epi,
        "road_structure_flip_rate": metrics["road_structure_flip_sum"] / n_epi,
        "scene_flip_rate": metrics["scene_flip_sum"] / n_epi,
        "step3_trigger_rate": metrics["step3_sum"] / n_epi,
        "status_acc_given_correct_scene": metrics["status_sum"] / n_epi,
        "subgoal_acc_given_correct_scene": metrics["subgoal_sum"] / n_epi,
        "all_acc_per_step": metrics["all_sum"] / n_epi,
        "invalid_road_structure_rate": metrics["invalid_road_structure_sum"] / n_epi,
        "invalid_scene_rate": metrics["invalid_scene_sum"] / n_epi,
        "invalid_status_for_pred_scene_rate": metrics["invalid_status_sum"] / n_epi,
        "invalid_subgoal_for_pred_scene_rate": metrics["invalid_subgoal_sum"] / n_epi,
        "scene_recovery_steps": (
            metrics["scene_recover_sum"] / max(metrics["scene_recover_count"], 1)
            if metrics["scene_recover_count"] > 0
            else -1
        ),
    }

    for pk in phase_keys:
        f = max(metrics[f"{pk}/frames"], 1)
        s3 = max(metrics[f"{pk}/step3_total"], 1)
        summary[f"{pk}_road_structure_acc"] = metrics[f"{pk}/road_structure_correct"] / f
        summary[f"{pk}_step2_fire_rate"] = metrics[f"{pk}/step2_total"] / f
        summary[f"{pk}_scene_acc_per_step"] = metrics[f"{pk}/scene_correct"] / f
        summary[f"{pk}_step3_trigger_rate"] = metrics[f"{pk}/step3_total"] / f
        summary[f"{pk}_status_acc_given_correct_scene"] = metrics[f"{pk}/status_correct"] / s3
        summary[f"{pk}_subgoal_acc_given_correct_scene"] = metrics[f"{pk}/subgoal_correct"] / s3
        summary[f"{pk}_all_acc_per_step"] = metrics[f"{pk}/all_correct"] / f
        summary[f"{pk}_scene_recovery_steps"] = (
            metrics[f"{pk}/scene_recover_sum"] / max(metrics[f"{pk}/scene_recover_count"], 1)
            if metrics[f"{pk}/scene_recover_count"] > 0
            else -1
        )

    if args.with_teacher_ref:
        summary["analysis_bleu_vs_teacher"] = (
            metrics["analysis_bleu_sum"] / max(metrics["analysis_bleu_count"], 1)
            if metrics["analysis_bleu_count"] > 0
            else -1
        )

    (out_dir / "metrics.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "episodes.json").write_text(json.dumps(per_episode, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
