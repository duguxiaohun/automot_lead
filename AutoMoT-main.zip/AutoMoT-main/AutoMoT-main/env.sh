# === AutoMoT project env ===

# 禁用 core dump，避免进程崩溃时在工作目录生成超大 core.* 文件。
ulimit -S -c 0 2>/dev/null || true

# CARLA 0.9.15
export CARLA_ROOT=/datashare/CARLA_0915
export CARLA_SERVER=$CARLA_ROOT/CarlaUE4.sh

# 项目根目录
export WORK_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)

# PYTHONPATH(用 guard 避免重复 source 时叠加)
if [[ -z "$_AUTOMOT_PYPATH_LOADED" ]]; then
    export _AUTOMOT_PYPATH_LOADED=1
    export PYTHONPATH=$CARLA_ROOT/PythonAPI/carla:$CARLA_ROOT/PythonAPI/carla/agents:$CARLA_ROOT/PythonAPI:$WORK_DIR:$PYTHONPATH
fi

# 之后 clone Bench2Drive 后再放开下面三行
# export LEADERBOARD_ROOT=$WORK_DIR/leaderboard
# export SCENARIO_RUNNER_ROOT=$WORK_DIR/scenario_runner
# export PYTHONPATH=$LEADERBOARD_ROOT:$SCENARIO_RUNNER_ROOT:$PYTHONPATH

echo "[AutoMoT] env loaded. CARLA_ROOT=$CARLA_ROOT"
